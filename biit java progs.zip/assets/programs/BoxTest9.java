class Box 
{
	private double width;
	private double height;
	private double depth;
	
	Box(double width, double height, double depth)
	{
		this.width = width;
		this.height = height;
		this.depth = depth;
	}
	
	double volume() 
	{
		return width * height * depth;
	}
}

class  BoxTest9
{
	public static void main(String args[ ]) 
	{
		Box b1 = new Box(10, 15, 20);
		Box b2 = new Box(5, 6, 7);
		
		System.out.println("Volume is " + b1.volume());
		System.out.println("Volume is " + b2.volume());
	}
}
