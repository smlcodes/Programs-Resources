import java.awt.*;
import java.applet.*;

/*
<applet code="drawPolygonTest1a" width="200" height="100" >
</applet>
*/

public class  drawPolygonTest1a  extends Applet  
{
	public void paint(Graphics g) 
	{
		setBackground( Color.yellow );
		int x[ ] = {20, 180, 180, 20, 100, 20};
		int y[ ] = {20, 20, 80, 80, 50, 20};
		int num = 6;
		g.drawPolygon(x, y, num);
	}
}
