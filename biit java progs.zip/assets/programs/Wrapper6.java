class  Wrapper6
{
	public static void main(String args[ ]) 
	{
		Integer iOb = 2;
		
		switch(iOb) 
		{
			case 1: 
				System.out.println("one");
				break;
			case 2: 
				System.out.println("two");
				break;
			case 3: 
				System.out.println("three");
				break;
			case 4: 
				System.out.println("four");
				break;
			case 5: 
				System.out.println("five");
				break;
			default: 
				System.out.println("default");
				break;
		}
	}
}
