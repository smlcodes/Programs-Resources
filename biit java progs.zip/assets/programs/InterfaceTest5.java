interface A
{
	void showA();
}

interface B 
{
	void showB();
}

interface C extends  A, B
{
	void showC();
}

class  D  implements  C
{
	public void showA()
	{
		System.out.println("showA() of A interface.");
	}
	
	public void showB()
	{
		System.out.println("showB() of B interface.");
	}
	
	public void showC()
	{
		System.out.println("showC() of C interface.");
	}
}

class  InterfaceTest5
{
	public static void main( String args[ ] )
	{
		C c1 = new  D();
		c1.showA();
		c1.showB();
		c1.showC();
	}
}
