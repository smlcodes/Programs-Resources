Resource
{
	int n = -1;
	boolean flag = true;

	synchronized void produce( int a )
	{
		while( !flag )
		{
			try
			{
				wait();
			}
			catch( InterruptedException e )  {   }
		}
		n = a;
		System.out.println( " Producer ::: " + n );	
		flag = false;
		notify();
	}

	synchronized int consume()
	{
		while( flag )
		{
			try
			{
				wait();
			}
			catch( InterruptedException e )  {   }
		}
		flag = true;
		notify();
		System.out.println( " Consumer ::: " + n );
		return n;
	}
}

class Producer extends Thread
{
	Resource s;
	
	Producer( Resource r )
	{
		super( "Producer" );
		s = r;		
	}

	public void run()
	{
		for( int i=1 ; i<=5 ; i++ )
		{
			try
			{
				Thread.sleep( 1000 );
			}
			catch( InterruptedException e )  {   }
			s.produce( i );
		}
		System.out.println( " Producer Terminating. " );
	}
}

class Consumer extends Thread
{
	Resource s;
	
	Consumer( Resource r )
	{
		super( "Consumer" );
		s = r;		
	}

	public void run()
	{
		int i;
		do
		{
			try
			{
				Thread.sleep( 1000 );
			}
			catch( InterruptedException e )
			{ }
			i = s.consume();
		} while( i != 5 );
		System.out.println("Consumer Terminating. " );
	}
}

class WaitNotifyDemo1
{
	public static void main(String args[ ])
	{
		Resource r = new Resource();
		Producer p = new Producer( r );
		Consumer c = new Consumer( r );
		p.start();
		c.start();
	}
}
