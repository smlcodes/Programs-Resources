import java.sql.*;

public class  JdbcTest9
{
	public static void main(String[ ] args) throws Exception 
	{
		int rno = 0, age = 0;
		String name = "", address = "";
		String qry = "";
		
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		String url = "jdbc:odbc:OracleDSN";

		Connection cn = DriverManager.getConnection(url, "system", "tiger");
		
		Statement st = cn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
		
		qry = "SELECT * FROM studentstb";
		ResultSet rs = st.executeQuery(qry);

		int rows = 0;
		while( rs.next())
			rows++;

		System.out.println("Rno\tName\tAge\tAddress");
		for (int i = 1; i <= rows; i++) 
		{
			rs.absolute(i);
			rno = rs.getInt(1);
			name = rs.getString(2);
			age = rs.getInt(3);
			address = rs.getString(4);
			System.out.println("" + rno + "\t" + name + "\t" 
+ age + "\t" + address);
		}

		rs.close();
		st.close();
		cn.close();
	}
}
