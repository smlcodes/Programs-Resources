import java.awt.*;
import java.applet.*;
import java.net.*;

/*
<applet code="Applet07" width="300" height="50">
</applet>
*/

public class  Applet07  extends Applet
{
	public void paint(Graphics g) 
	{
		String msg;
		
		URL url = getCodeBase(); // get code base
		msg = "Code base: " + url.toString();
		g.drawString(msg, 10, 20);

		url = getDocumentBase(); // get document base
		msg = "Document base: " + url.toString();
		g.drawString(msg, 10, 40);
	}
}
