class  Shape
{
	void draw()
	{
		System.out.println("Drawing Shape.");
	}
}

class  Rectangle extends Shape
{
	void draw()
	{
		System.out.println("Drawing Rectangle.");
	}
}

class  Triangle extends Shape
{
	void draw()
	{
		System.out.println("Drawing Triangle.");
	}
}

class  PolymorphismTest6
{
	public static void main( String args[ ] )
	{
		Shape s = new Shape();
		s.draw();
		
		Rectangle r = new Rectangle();
		s = r;
		s.draw();
		
		Triangle t = new Triangle();
		s = t;
		s.draw();
	}
}
