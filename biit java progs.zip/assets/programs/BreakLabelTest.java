class BreakLabelTest 
{
	public static void main( String args[] )
	{
		int i, j;
		Outer: for( i=1 ; i<=10 ; i++ )
		{
			Inner: for( j=1 ; j<=10 ; j++ )
			{
				System.out.print(" " + j);
				if( i == j )
				{
					System.out.println();
					break Inner;
				}
				else if( j==5 )
				{
					break Outer;
				}
			}
		}
	}
}
