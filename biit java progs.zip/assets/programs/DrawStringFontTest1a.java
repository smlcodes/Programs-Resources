import java.awt.*;
import java.applet.*;

/*
<applet code="DrawStringFontTest1a" width="200" height="100" >
</applet>
*/

public class  DrawStringFontTest1a  extends Applet  
{
	Font f;
	
	public void init() 
	{
		setBackground( Color.yellow );
		f = new Font("Serif", Font.PLAIN, 35);
		setFont( f );
	}
	
	public void paint(Graphics g) 
	{		
		g.drawString("BIIT", 50, 70);
	}
}
