class  RecursionPower
{
	public static void main(String[ ] args) 
	{
		double x = 5.0, p;
		int n = 3;
		p = power( x, n );
		System.out.println(" " + x + " raised to the power " + n + " = " + p);
	}
	
	public static double power( double x, int n ) 
	{
		if(n == 0)
			return 1;
		else
			return ( x * power(x, n-1));
	}
}
