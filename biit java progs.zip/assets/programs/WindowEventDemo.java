import java.awt.*;
import java.awt.event.*;

public class WindowEventDemo extends Frame implements WindowListener
{
	public WindowEventDemo()
	{
		addWindowListener( this );
		setSize( 250, 150 );
		setVisible( true );
	}

	public void windowOpened( WindowEvent we )
	{
		System.out.println( "Window Opened" );
	}

	public void windowIconified( WindowEvent we )
	{
		System.out.println( "Window Iconified" );
	}
	
	public void windowDeiconified( WindowEvent we )
	{
		System.out.println( "Window Deiconified" );
	}
    
	public void windowActivated( WindowEvent we )
	{
		System.out.println( "Window Activated" );
	}
    
	public void windowDeactivated( WindowEvent we )
	{
		System.out.println( "Window Deactivated" );
	}
    
	public void windowClosing( WindowEvent we )
	{
		dispose();
		System.out.println( "Window Closing" );
	}
    
	public void windowClosed( WindowEvent we )
	{
		System.out.println( "Window Closed" );
		System.exit( 0 );
	}

	public static void main( String[ ] args )
	{
		Frame f = new WindowEventDemo();
	}
}
