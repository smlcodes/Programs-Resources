class Wrapper2
{
	public static void main( String args[ ] )
	{
		// Autoboxing
		Integer iOb = 100; 	

		// Auto-unboxing
		int i = iOb; 		

		System.out.println(i + " : " + iOb); 
	}
}
