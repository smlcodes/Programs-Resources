import java.applet.*;
import java.awt.*;
import java.awt.event.*;

class MyDialog extends Dialog implements ActionListener
{
  	Button b1;
  	Label l1;
  	
  	MyDialog( Frame f, String s, boolean u )
  	{
		super( f, s, u );
		setLayout( new FlowLayout() );
		b1 = new Button( "OK" );
		l1 = new Label();
		
		add( l1 );
		add( b1 );
		
		b1.addActionListener( this );
   	}

   	public void actionPerformed( ActionEvent e )
   	{
		if( e.getSource() == b1 )
		{
			this.setVisible( false );
		}
	}
}

class MyFrame extends Frame implements ActionListener
{
  	Button b1;
  	TextField t1;
  	MyDialog d;
  	String s1, s2;

  	MyFrame()
  	{
		super( " DIALOG DEMO " );
		d = new MyDialog( this, "Dialog Box", true );

		d.setSize( 200, 100 );
		d.setLocation( 300, 200 );
		setLayout( new FlowLayout() );
		
		Label l1 = new Label("Enter String: ");
		b1 = new Button( " REVERSE " );
		t1 = new TextField( 20 );

		add( l1 );
		add( t1 );
		add( b1 );		
      
		b1.addActionListener( this );
   	}

   	public void actionPerformed( ActionEvent e )
   	{
		if( e.getSource() == b1 )
		{
			s1 = t1.getText();
			StringBuffer s = new StringBuffer( s1 );
			s2 = new String( s.reverse() );
			d.l1.setText( "Reversed String : " + s2 );
			d.l1.setVisible( true );
			d.setVisible( true );
		}
	}
} 

class DialogTest
{
  	public static void main( String args[] )
  	{
		MyFrame f = new MyFrame();
		f.setSize( 250, 200 );
		f.setLocation(300, 200);
		f.setBackground( Color.cyan );
		f.setVisible(true);
		
		f.addWindowListener( new WindowAdapter()
		{
			public void windowClosing( WindowEvent e )
			{ 
				System.exit( 0 );
			}
		} );
  	}
}
