import java.io.*;

class FileOutputStreamDemo
{
	public static void main( String args[ ] ) throws 
     IOException
	{
		// attach keyboard to DataInputStream
		DataInputStream dis = new DataInputStream( System.in );
		
		// attach file to FileOutputStream
		FileOutputStream fos = new FileOutputStream( "file1.txt" );
		
		System.out.println("Enter string($ to end): ");
		char ch;
		
		// read character from dis into ch and write them into fos.
		while( (ch=(char)dis.read()) != '$' )
		{
			fos.write(ch);
		}
		
		// close the file.
		fos.close();
	}
}
