import java.awt.*;
import java.applet.*;

/*
<applet code="LabelDemo" width=300 height=100>
</applet>
*/

public class LabelDemo extends Applet 
{
	public void init() 
	{
		Label l1 = new Label("BIIT");
		Label l2 = new Label("Computer");
		Label l3 = new Label("Education");
		
		// add labels to applet window
		add(l1);
		add(l2);
		add(l3);
	}
}
