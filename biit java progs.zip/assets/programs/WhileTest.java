class  WhileTest
{
	public static void main( String args[ ] )
	{
		int  i = 1;			// 1.  Initialization

		while ( i <= 5 )	// 2.  Test / Condition
		{
			System.out.print( "  " + i );
			i++;			// 3.  Increment.
		}
	}
}
