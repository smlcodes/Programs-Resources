import java.awt.*;
import java.applet.*;

/*
<applet code="DrawRoundRectTest1a" width="200" height="100" >
</applet>
*/

public class DrawRoundRectTest1a  extends  Applet  
{
	public void paint(Graphics g) 
	{
		setBackground( Color.yellow );
		g.drawRoundRect (15, 15, 165, 65, 30, 20);  
	}
}
