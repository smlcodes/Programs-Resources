import java.sql.*;

public class JdbcTest11
{
	public static void main(String[ ] args) throws Exception 
	{
		int rno = 0, age = 0;
		String name = "", address = "";
		String qry = "";
		
		rno = Integer.parseInt(args[0]);
		name = args[1];
		age = Integer.parseInt(args[2]);
		address = args[3];
		
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		String url = "jdbc:odbc:OracleDSN";

		Connection cn = DriverManager.getConnection(url, "system", "tiger");
		
		qry = "insert into studentstb(rno, sname, age, address ) values (?, ?, ?, ?);";
		
		PreparedStatement pst = cn.prepareStatement(qry);
		pst.setInt(1, rno);
		pst.setString(2, name);
		pst.setInt(3, age);
		pst.setString(4, address);
		
		pst.execute();
		
		Statement st = cn.createStatement();
		qry = "SELECT * FROM studentstb";
		ResultSet rs = st.executeQuery(qry);

		System.out.println("Rno\tName\tAge\tAddress");
		while (rs.next()) 
		{
			rno = rs.getInt(1);
			name = rs.getString(2);
			age = rs.getInt(3);
			address = rs.getString(4);
			System.out.println("" + rno + "\t" + name + "\t" + age + "\t" + address);
		}

		rs.close();
		st.close();
		cn.close();
	}
}
