class ReturnTest1
{
	public static void main( String args[] )
	{
		System.out.println( "AAA" );
		funTest();
		System.out.println( "DDD" );
	}
	
	public static void funTest()
	{
		int a = 10;
		System.out.println( "BBB" );
		if( a == 10 )
			return;
		System.out.println( "CCC" );
	}
}
