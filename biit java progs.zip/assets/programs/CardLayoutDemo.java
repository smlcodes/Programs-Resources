import java.awt.*;
import java.awt.event.*;
import java.applet.*;

/*
<applet code="CardLayoutDemo" width=300 height=100>
</applet>
*/

public class CardLayoutDemo extends Applet implements ActionListener, MouseListener 
{
	Button b1, b2, b3, b4, b5;
	Panel mainPanel;
	CardLayout cardLO;
	Button bCard1, bCard2;

	public void init() 
	{
		bCard1 = new Button("Card1");
		bCard2 = new Button("Card2");
		
		add(bCard1);
		add(bCard2);
		
		cardLO = new CardLayout();
		mainPanel = new Panel();
		mainPanel.setLayout(cardLO);		
		
		b1 = new Button("Button-1");
		b2 = new Button("Button-2");
		b3 = new Button("Button-3");
		b4 = new Button("Button-4");
		b5 = new Button("Button-5");
	
		Panel p1 = new Panel();
		p1.add(b1);
		p1.add(b2);
		p1.add(b3);

		Panel p2 = new Panel();
		p2.add(b4);
		p2.add(b5);

		mainPanel.add(p1, "Card1");
		mainPanel.add(p2, "Card2");

		add(mainPanel);

		bCard1.addActionListener(this);
		bCard2.addActionListener(this);

		addMouseListener(this);
	}
	
	public void mousePressed(MouseEvent me) 
	{
		cardLO.next(mainPanel);
	}
	
	public void mouseClicked(MouseEvent me) 
	{
	}

	public void mouseEntered(MouseEvent me) 
	{
	}

	public void mouseExited(MouseEvent me) 
	{
	}

	public void mouseReleased(MouseEvent me) 
	{
	}

	public void actionPerformed(ActionEvent ae) 
	{
		if(ae.getSource() == bCard1) 
		{
			cardLO.show(mainPanel, "Card1");
		}
		else 
		{
			cardLO.show(mainPanel, "Card2");
		}
	}
}
