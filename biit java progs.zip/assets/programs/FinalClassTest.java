final class A
{
	void display()
	{
		System.out.println(" A\'s display().");
	}
}

// final class can't be inherited.
// class B extends A			// Error
class B
{
	void display()
	{
		System.out.println(" B\'s display().");
	}
}

class  FinalClassTest
{
	public static void main( String args[ ] )
	{
		A a = new A();
		B b = new B();
		a.display();
		b.display();
	}
}
