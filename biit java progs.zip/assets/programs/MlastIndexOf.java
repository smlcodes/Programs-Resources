class  MlastIndexOf
{
	public static void main( String args[ ] )
	{
		String s1 = "BIIT Computer Education BIIT Computer Education.";
				
		System.out.println( " Last Index of " + 'C' + " = " + s1.lastIndexOf( 'C' ) );
		System.out.println( " Last Index of " + 'x' + " = " + s1.lastIndexOf( 'x' ) );
		System.out.println( " Last Index of " + "Computer" + " = " + s1.lastIndexOf( "Computer" ) );
		System.out.println( " Last Index of " + "COMPUTER" + " = " + s1.lastIndexOf( "COMPUTER" ) );
	}
}
