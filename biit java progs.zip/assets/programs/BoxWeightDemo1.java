class Box 
{
	double width;
	double height;
	double depth;

	Box(Box ob) 
	{ 
		width = ob.width;
		height = ob.height;
		depth = ob.depth;
	}

	Box(double w, double h, double d) 
	{
		width = w;
		height = h;
		depth = d;
	}
	
	Box() 
	{
		width = 1; 
		height = 1; 
		depth = 1; 
	}

	Box(double len) 
	{
		width = height = depth = len;
	}

	double volume() 
	{
		return width * height * depth;
	}
}

class BoxWeight extends Box 
{
	double weight; 

	BoxWeight(double w, double h, double d, double m) 
	{
		width = w;
		height = h;
		depth = d;
		weight = m;
	}
}

class  BoxWeightDemo1 
{
	public static void main(String args[ ]) 
	{
		BoxWeight wb = new BoxWeight(10, 15, 20, 25.75);
		Box b = new Box();
		double vol;
		vol = wb.volume();
		System.out.println("Volume of wb is " + vol);
		System.out.println("Weight of wb is " + wb.weight);
		System.out.println();
		
		// assign BoxWeight reference to Box reference
		b = wb;
		vol = b.volume(); 				// OK
		System.out.println("Volume of b is " + vol);
		/* The following statement is invalid because b
		does not define a weight member. */
		// System.out.println("Weight of b is " + b.weight);
	}
}
