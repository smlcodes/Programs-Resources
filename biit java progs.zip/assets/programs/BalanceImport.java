package MyPack;

public class  Balance 
{
	String name;
	double bal;

	public Balance(String n, double b) 
	{
		name = n;
		bal = b;
	}

	public void show() 
	{
		if(bal<0)
			System.out.print("--> ");
		System.out.println(name + ": Rs. " + bal);
	}
}

Second File [BalanceImport.java](in current folder) : 
import  MyPack.*;

class  BalanceImport 
{
	public static void main(String args[ ]) 
	{
		Balance ob = new Balance("Khushal", 234.56);
		ob.show(); 
	}
}
