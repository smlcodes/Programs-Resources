class CurrentThread
{
	public static void main( String args[ ] )
	{
		Thread t = Thread.currentThread();
		System.out.println( "Current Thread is = " + t );

		t.setName( "My Thread" );
		System.out.println( "After Changing Name is = " + t );
	}
}
