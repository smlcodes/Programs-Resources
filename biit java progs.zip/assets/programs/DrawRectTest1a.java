import java.awt.*;
import java.applet.*;

/*
<applet code="DrawRectTest1a" width="200" height="100" >
</applet>
*/

public class  DrawRectTest1a  extends  Applet  
{
	public void paint(Graphics g) 
	{
		setBackground( Color.yellow );
		g.drawRect (10, 10, 180, 80);  
	}
}
