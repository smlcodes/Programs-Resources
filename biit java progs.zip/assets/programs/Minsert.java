class  Minsert
{
	public static void main( String args[ ] )
	{
		String s = new String( "BIIT" );
		StringBuffer sb = new StringBuffer( " Education." );

		sb = sb.insert( 0, s );
		System.out.println( " String = " + sb );
		
		sb.insert( 5, "Computer " );
		System.out.println( " String = " + sb );
	}
}
