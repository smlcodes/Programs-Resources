import java.sql.*;

public class  JdbcTest14
{
	public static void main(String[ ] args) throws Exception 
	{
		int n1 = 0, n2 = 0, sm = 0;
		
		n1 = Integer.parseInt(args[0]);
		n2 = Integer.parseInt(args[1]);
		
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		String url = "jdbc:odbc:OracleDSN";

		Connection cn = DriverManager.getConnection(url, "system", "tiger");
		CallableStatement cst = cn.prepareCall("{?=Call Addition(?, ?)}");
		
		cst.setInt(2, n1);
		cst.setInt(3, n2);		
		cst.registerOutParameter(1, Types.INTEGER);
		
		cst.execute();
		
		sm = cst.getInt(1);		
		System.out.println(""+n1 + " + " + n2 + " = " + sm);
		
		cst.close();
		cn.close();
	}
}

( Stored Procedure in Oracle) : 
create or replace function Addition( a number, b number) 
return number
as
	s number(5);
begin
	s := a + b;
	return s;
end;
