class  VarArgs5
{
	static void vaTest(String msg, int... v) 
	{
		System.out.println("No. of Args : " + v.length);
		System.out.print(msg);
		for (int x : v) 
		{
			System.out.print(x + " ");
		}
		System.out.println();
	}

	public static void main(String args[ ]) 
	{
		vaTest("One vararg: ", 10);
		vaTest("Three varargs: ", 1, 2, 3);
		vaTest("No varargs: ");
	}
}
