class  A
{
	public void displayMsg()
	{
		System.out.println( "Let's learn JAVA !!!" );
	}
	
	public void  displayMsg( String msg)
	{
		System.out.printf( "Welcome to %s !!!\n", msg );
	}
} 

public class  MethodOverloadingClass
{
	public static void main( String args[ ] )
	{ 
		A ob = new A(); 
		String s = "BIIT";
		ob.displayMsg(s); 
		ob.displayMsg(); 
	}
}
