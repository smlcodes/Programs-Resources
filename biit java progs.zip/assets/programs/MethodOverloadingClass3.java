class  A
{
	public void display(int[ ] i)
	{
		System.out.print(" int Array : " );
		for( int a : i )
			System.out.print( " " + a );
	}
	
	public void  display(double[ ] d)
	{
		System.out.print(" double Array : " );
		for( double a : d )
			System.out.print( " " + a );
	}
	
	public void display(String[ ] s)
	{
		System.out.print(" String Array : " );
		for( String a : s )
			System.out.print( " " + a );
	}
} 

public class  MethodOverloadingClass3
{
	public static void main( String args[ ] )
	{ 
		A ob = new A(); 
		int a[ ] = { 10, 20, 30, 40, 50 };
		double b[ ] = { 12.3, 23.4, 34.5, 45.6, 56.7 };
		String c[ ] = { "67/6-B", "Maitri Nagar", "Bhilai", "C.G." };
		ob.display(a); 
		ob.display(b); 
		ob.display(c); 
	}
}
