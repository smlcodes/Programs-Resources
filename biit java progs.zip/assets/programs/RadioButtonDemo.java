import java.awt.*;
import java.awt.event.*;
import java.applet.*;

/*
<applet code="RadioButtonDemo" width="250" height="100">
</applet>
*/

public class RadioButtonDemo extends Applet implements ItemListener 
{
	String msg = "";
	Checkbox  cbRed, cbGreen, cbBlue;
	CheckboxGroup  cbg;

	public void init() 
	{
		cbg = new CheckboxGroup();
		
		cbRed = new Checkbox("Red", cbg, true);
		cbGreen = new Checkbox("Green", cbg, false);
		cbBlue = new Checkbox("Blue", cbg, false);
		
		add(cbRed);
		add(cbGreen);
		add(cbBlue);
		
		cbRed.addItemListener(this);
		cbGreen.addItemListener(this);
		cbBlue.addItemListener(this);
	}
	
	public void itemStateChanged(ItemEvent ie) 
	{
		repaint();
	}

	public void paint(Graphics g) 
	{
		msg = "Color Selection: ";
		msg += cbg.getSelectedCheckbox().getLabel();
		g.drawString(msg, 6, 100);
	}
}
