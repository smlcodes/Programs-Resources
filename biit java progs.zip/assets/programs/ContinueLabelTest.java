class ContinueLabelTest 
{
	public static void main( String args[] )
	{
		int i, j;
		Outer: for( i=1 ; i<=5 ; i++ )
		{
			Inner: for( j=1 ; j<=5 ; j++ )
			{
				System.out.print(" " + j);
				if( i == j )
				{
					System.out.println();
					continue Outer;
				}
			}
		}
	}
}
