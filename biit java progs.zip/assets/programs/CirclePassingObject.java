class  Circle
{
	private double radius;
	
	Circle()
	{
		radius = 0.0;
	}
	
	Circle( double radius)
	{
		this.radius = radius;
	}
	
	public double area()
	{
		return 3.14 * radius * radius;
	}
} 

public class  CirclePassingObject
{
	public static void main( String args[ ] )
	{ 
		Circle c1 = new Circle(20); 
		
		calcArea( c1 );
	}
	
	public static void calcArea( Circle c )
	{
		System.out.println(" Area of Circle : " + c.area()); 
	}
}
