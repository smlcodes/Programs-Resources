class Constant1
{
	static final int NUMBER_OF_MONTHS = 12;
	static final double PI = (double) 22 / 7;

	public static void main( String args[] )
	{
		System.out.println("NUMBER_OF_MONTHS : " + NUMBER_OF_MONTHS );
		System.out.println("PI : " + PI );
	}
}
