import java.io.*;
import java.util.*;

// Box class
class Box  implements  Serializable
{
	// instance variables
	private double width;
	private double height;
	private double depth;
	
	// default constructor
	Box()
	{
		width = 0;
		height = 0;
		depth = 0;
	}
	
	// parameterized constructor
	Box( double w, double h, double d )
	{
		width = w;
		height = h;
		depth = d;
	}
	
	// display box
	void display()
	{
		System.out.println(" Width = " + width);
		System.out.println(" Heidth = " + height);
		System.out.println(" Depth = " + depth);
	}
}

class DeSerializationDemo
{
	public static void main( String args[ ] ) throws Exception
	{
		// attach FileInputStream to file.
		FileInputStream fis = new FileInputStream( "ObjFile" );
		
		// attach ObjectInputStream to FileInputStream.
		ObjectInputStream ois = new ObjectInputStream( fis );
		
		// read object (b1) from 'ois'
		Box b1;
		b1 = (Box)ois.readObject();
		b1.display();
		
		ois.close();		
	}
}
