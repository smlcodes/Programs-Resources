enum Colour 
{
	Red, Green, Blue, Black, White, Orange, Yellow
}

class EnumDemo1 
{
	public static void main(String args[ ])
	{
		Colour c1;
		c1 = Colour.Red;
		System.out.println("Value of c1: " + c1);

		c1 = Colour.Blue;
		if(c1 == Colour.Blue)
			System.out.println("c1 contains Blue.");

		switch(c1) 
		{
			case Red:
				System.out.println("c1 is red.");
				break;
			case Green:
				System.out.println("c1 is green.");
				break;
			case Blue:
				System.out.println("c1 is blue.");
				break;
			case Black:
				System.out.println("c1 is black.");
				break;
			case White:
				System.out.println("c1 is white.");
				break;
			case Orange:
				System.out.println("c1 is orange.");
				break;
			case Yellow:
				System.out.println("c1 is yellow.");
				break;
		}
	}
}
