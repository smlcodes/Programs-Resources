class ConditionalOper
{
	public static void main( String args[ ] )
	{
       	int a, b, max;

		a = Integer.parseInt( args[0] );
		b = Integer.parseInt( args[1] );

		max = ( ( a > b ) ? a : b );
		System.out.print("\nMaximum Value is=" + max );
	}
}
