import java.awt.*;
import javax.swing.*;

/*
<applet code="SwingJTable" width=400 height=200>
</applet>
*/

public class SwingJTable extends JApplet 
{
	public void init() 
	{
		try 
		{
			SwingUtilities.invokeAndWait(new Runnable() 
			{
				public void run() 
				{
					makeGUI();
				}
			} );
		} 
		catch (Exception e) 
		{
			System.out.println("Exception : " + e);
		}
	}
	
	private void makeGUI() 
	{
		String[ ] colHeads = { "Name", "Age", "Address" };
		Object[ ][ ] data = {	{ "Komal", "21", "Housing Board" },
						{ "Anwesha", "21", "Ruabandha" },
						{ "Gargi", "20", "Sector-6" },
						{ "Ankit", "22", "Pragati Nagar" },
						{ "Srishti", "20", "Maitri Nagar" },
						{ "Vibha", "21", "Ashish Nagar" },
						{ "Geetanjali", "21", "Risali" },
						} ;

		JTable table = new JTable(data, colHeads);
		JScrollPane jsp = new JScrollPane(table);
		add(jsp);
	}
}
