public class  RetIntRef
{
	public int[ ] test()
	{
		int  a[ ] = { 10, 9, 8, 7, 6, 5, 4, 3, 2, 1 };
		return  a;
	}

	public static void main( String[ ] args )
	{
		RetIntRef  ob = new RetIntRef();
		
		int  x[ ] = ob.test();
		
		for( int  i=0 ; i<x.length ; i++ )
		{
				System.out.println( x[ i ] );
		}
	}
}
