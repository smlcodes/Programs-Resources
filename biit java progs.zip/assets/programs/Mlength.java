class  Mlength
{
	public static void main( String args[ ] )
	{
		char ch[ ] = { 'B', 'I', 'I', 'T' };
		String s1 = new String( ch );	

		System.out.println( " String = " + s1 );
		System.out.println( " Length = " + s1.length() );
		System.out.println( " Length = " + "BIIT Computer Education".length() );
	}
}
