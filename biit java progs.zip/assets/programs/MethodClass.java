public class  MethodClass
{
	public static void main( String args[ ] )
	{ 
		A ob = new A(); 

		ob.displayMsg(); 
	}
}

class  A
{
	public void displayMsg()
	{
		System.out.printf( "Welcome to BIIT !!!\n" );
	}
}
