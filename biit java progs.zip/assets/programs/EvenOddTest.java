class EvenOddTest
{
	public static void main( String args[] )
	{
		int n;

		n = Integer.parseInt( args[0] );

		if( n % 2 == 0 )
			System.out.println("Number " + n + " is Even Number." );
		else
			System.out.println("Number " + n + " is Odd Number." );
	}
}
