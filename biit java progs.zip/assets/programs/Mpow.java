class  Mpow
{
	public static void main( String args[ ] )
	{
		double n = Math.pow( 5, 3 );
		System.out.println( " 5 ^ 3 : " + n );
	}
}
