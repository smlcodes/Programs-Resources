abstract class Shape
{
	abstract void draw();
}

class Rectangle extends Shape
{
	void draw()
	{
		System.out.println("Drawing Rectangle.");
	}
}

class Triangle extends Shape
{
	void draw()
	{
		System.out.println("Drawing Triangle.");
	}
}

class  PolymorphismTest7
{
	public static void main( String args[ ] )
	{
		// Can't instantiate Shape class.
		// Shape s = new Shape();
		// s.draw();
		
		Shape s;
		
		Rectangle r = new Rectangle();
		s = r;
		s.draw();
		
		Triangle t = new Triangle();
		s = t;
		s.draw();
	}
}
