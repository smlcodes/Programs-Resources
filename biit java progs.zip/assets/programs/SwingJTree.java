import java.awt.*;
import javax.swing.event.*;
import javax.swing.*;
import javax.swing.tree.*;

/*
<applet code="SwingJTree" width=400 height=200>
</applet>
*/
public class SwingJTree extends JApplet 
{
	JTree tree;
	JLabel jlab;
	
	public void init() 
	{
		try 
		{
			SwingUtilities.invokeAndWait(new Runnable() 
			{
				public void run() 
				{
					makeGUI();
				}
			} );
		} 
		catch (Exception e) 
		{
			System.out.println("Exception : " + e);
		}
	}
	
	private void makeGUI() 
	{
		DefaultMutableTreeNode a = new DefaultMutableTreeNode("A");
		
		DefaultMutableTreeNode a1 = new DefaultMutableTreeNode("A1");
		a.add(a1);
		
		DefaultMutableTreeNode a11 = new DefaultMutableTreeNode("A11");
		a1.add(a11);
		DefaultMutableTreeNode a12 = new DefaultMutableTreeNode("A12");
		a1.add(a12);
		DefaultMutableTreeNode a13 = new DefaultMutableTreeNode("A13");
		a1.add(a13);

		DefaultMutableTreeNode b1 = new DefaultMutableTreeNode("B1");
		a.add(b1);
		
		DefaultMutableTreeNode b11 = new DefaultMutableTreeNode("B11");
		b1.add(b11);
		DefaultMutableTreeNode b12 = new DefaultMutableTreeNode("B12");
		b1.add(b12);
		DefaultMutableTreeNode b13 = new DefaultMutableTreeNode("B13");
		b1.add(b13);

		tree = new JTree(a);
		JScrollPane jsp = new JScrollPane(tree);
		add(jsp);

		jlab = new JLabel();
		add(jlab, BorderLayout.SOUTH);

		tree.addTreeSelectionListener(new TreeSelectionListener() 
		{
			public void valueChanged(TreeSelectionEvent tse) 
			{
				jlab.setText("Selection is " + tse.getPath());
			}
		});
	}
}
