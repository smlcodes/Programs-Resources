class  MStringBuffer1
{
	public static void main(String args[ ])
	{
		StringBuffer sb = new StringBuffer("BIIT");
		
		System.out.println(" sb = " + sb );
	
		sb = sb.append(" Computer");
		System.out.println(" sb = " + sb );
		
		sb = sb.append(" Education.");
		System.out.println(" sb = " + sb );	
	}
}
