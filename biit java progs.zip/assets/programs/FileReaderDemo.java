import java.io.*;

class FileReaderDemo
{
	public static void main( String args[ ] ) throws IOException
	{
		// attach file to FileReader
		FileReader fr = null;
		try
		{
			fr = new FileReader( "file1.txt");
		}
		catch( FileNotFoundException fnfe )
		{
			System.out.println(" File Not found.");
			return;
		}
		
		// read character from FileReader.
		int ch;
		System.out.println(" File Contents are : ");
		while( (ch = fr.read()) != -1 )
		{
			System.out.print((char)ch);
		}

		// close the file.
		fr.close();
	}
}
