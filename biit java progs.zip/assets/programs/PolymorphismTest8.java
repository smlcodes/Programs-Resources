interface Shape
{
	void draw();
}

class Rectangle implements Shape
{
	public void draw()
	{
		System.out.println("Drawing Rectangle.");
	}
}

class Triangle implements Shape
{
	public void draw()
	{
		System.out.println("Drawing Triangle.");
	}
}


class  PolymorphismTest8 
{
	public static void main( String args[ ] )
	{
		Shape s;
		
		Rectangle r = new Rectangle();
		s = r;
		s.draw();
		
		Triangle t = new Triangle();
		s = t;
		s.draw();
	}
}
