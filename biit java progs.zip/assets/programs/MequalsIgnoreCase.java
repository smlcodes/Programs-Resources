class  MequalsIgnoreCase
{
	public static void main( String args[ ] )
	{
		String s1 = "BIIT";	
		String s2 = "BIIT";
		String s3 = "biit";

		System.out.println( s1 + " equals " + s2 + " = " + s1.equals( s2 ) );
	    System.out.println(s1 +"equalsIgnoreCase " + s3 + " = " + s1.equalsIgnoreCase( s3 ) );
	}
}
