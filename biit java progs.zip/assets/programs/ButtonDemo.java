import java.awt.*;
import java.awt.event.*;
import java.applet.*;

/*
<applet code="ButtonDemo" width=250 height=150>
</applet>
*/

public class ButtonDemo extends Applet implements ActionListener 
{
	String msg = "";
	Button b1, b2, b3;
	
	public void init() 
	{
		b1 = new Button("BIIT");
		b2 = new Button("Computer");
		b3 = new Button("Education");
		
		add(b1);
		add(b2);
		add(b3);
		
		b1.addActionListener(this);
		b2.addActionListener(this);
		b3.addActionListener(this);
	}
	
	public void actionPerformed(ActionEvent ae) 
	{
		String str = ae.getActionCommand();
		
		if(str.equals("BIIT")) 
		{
			msg = "You clicked BIIT.";
		}
		else if(str.equals("Computer")) 
		{
			msg = "You clicked Computer.";
		}
		else 
		{
			msg = "You clicked Education.";
		}
		repaint();
	}

	public void paint(Graphics g) 
	{
		g.drawString(msg, 6, 100);
	}
}
