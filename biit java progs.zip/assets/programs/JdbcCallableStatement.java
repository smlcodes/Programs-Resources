import java.sql.*;

class  JdbcCallableStatement
{ 
	public static void main( String args[ ] ) 
	{ 
		int grade;
		String res;

		try
		{
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver" );
			String url = "jdbc:odbc:DSN_Name";		
			Connection cn = DriverManager.getConnection( url, "username", "password" );

			CallableStatement cst = cn.prepareCall( "{ ? = call getStudentGrade( ?, ? ) }" );		
			
			cst.registerOutParameter( 1, java.sq..Types.INTEGER );
			cst.setString( 2, studentID );
			cst.setString( 3, classID );

			cst.executeUpdate();
			grade = cst.getInt( 1 );

			System.out.println( " Grade = " + grade );
		}	
		catch( Exception e )
		{
			System.out.println( e.getMessage() ); 
		}
	} 
} 
