class  Mtrim
{
	public static void main( String args[ ] )
	{
		String s = "            BIIT Computer Education.           ".trim();
		System.out.print( "String after Trim : |" + s + �|� );
	}
}
