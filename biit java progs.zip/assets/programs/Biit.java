class  Biit
{
	public static void main( String args[ ] )
	{
		System.out.println("Let  us learn JAVA." );
	}
}
