class  Mcapacity
{
	public static void main( String args[ ] )
	{
		StringBuffer sb1 = new StringBuffer();
		StringBuffer sb2 = new StringBuffer( "BIIT Computer Education" );

		System.out.println( " Capacity = " + sb1.capacity() );
		System.out.println( " Capacity = " + sb2.capacity() );		
	}
}
