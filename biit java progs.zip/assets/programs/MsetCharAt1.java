class  MsetCharAt1
{
	public static void main( String args[ ] )
	{
		StringBuffer sb1 = new StringBuffer( "BIIT Tomputer Education." );
		System.out.println( " String Before Replacing = " + sb1 );
		
		sb1.setCharAt( 5, 'C' );

		System.out.println( " String After Replacing  = " + sb1 );
	}
}
