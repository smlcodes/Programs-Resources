class  Mreverse
{
	public static void main( String args[ ] )
	{
		StringBuffer sb = new StringBuffer( "BIIT Computer Education." );

		System.out.println( " String = " + sb );
		
		sb.reverse();

		System.out.println( " String = " + sb );
	}
}
