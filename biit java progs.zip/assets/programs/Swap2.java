import java.io.*;

class  Swap2
{
	public static void main( String args[ ] ) throws IOException
	{
		int  a=0, b=0, t;

		InputStreamReader isr = new InputStreamReader( System.in );
		BufferedReader br = new BufferedReader( isr );
		
		System.out.print(" Enter first Number : ");
		a = Integer.parseInt(br.readLine());
		System.out.print(" Enter second Number : ");
		b = Integer.parseInt(br.readLine());
		 
		System.out.print( "\n Before Swapping : " );
		System.out.print( a + "   " + b );

		a = a ^ b;
		b = a ^ b;
		a = a ^ b;
		
		System.out.print( "\n After Swapping  : " );
		System.out.print( a + "   " + b );
	}
}
