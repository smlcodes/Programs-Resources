import java.awt.*;
import java.applet.Applet;

/*
<applet code="AppletTest2b.class" width="300" height="100">
	<param name="message" value="BIIT Computer Education" />
</applet>
*/

public class  AppletTest2b  extends  Applet 
{
	String msg = "";
	
	public void init() 
	{
		setBackground( Color.yellow );
		msg = getParameter("message");
	}
	
	public void paint( Graphics g ) 
	{
		g.drawString( msg, 50, 50 );
		System.out.println(msg);
	}
}
