class LifeTime1 
{
	public static void main(String args[ ]) 
	{
		int i;
		for(i = 1; i <= 5; i++) 
		{
			increment();
		}
	}
	
	private static void increment()
	{
		int  x = 10;
		x++;
		System.out.println(" " + x );
	}
}
