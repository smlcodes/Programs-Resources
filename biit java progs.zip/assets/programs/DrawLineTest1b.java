import java.awt.*;

public class DrawLineTest1b  extends  Frame  
{

	public DrawLineTest1b()
	{
		setSize(200, 200);
		setVisible(true);
	}
	
	public void paint(Graphics g) 
	{
		g.drawLine(20, 40, 180, 180);
	}
	
	public static void main(String[ ] a) 
	{
		DrawLineTest1b f = new DrawLineTest1b();
	}
}
