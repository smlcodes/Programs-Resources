import java.awt.*;
import java.awt.event.*;
import java.applet.*;

/*
<applet  code="MouseEventTest1"  width="300" height="200">
</applet>
*/

public class MouseEventTest1 extends Applet implements MouseListener 
{
	String msg = "";
	int mouseX = 0, mouseY = 0; 

	public void init() 
	{
		addMouseListener(this);
	}
	
	// Handle mouse clicked.
	public void mouseClicked(MouseEvent me) 
	{
		mouseX = 0;
		mouseY = 10;
		msg = "Mouse clicked.";
		repaint();
	}
	
	// Handle mouse entered.
	public void mouseEntered(MouseEvent me) 
	{
		mouseX = 0;
		mouseY = 10;
		msg = "Mouse entered.";
		repaint();
	}
	
	// Handle mouse exited.
	public void mouseExited(MouseEvent me) 
	{
		mouseX = 0;
		mouseY = 10;
		msg = "Mouse exited.";
		repaint();
	}
	
	// Handle button pressed.
	public void mousePressed(MouseEvent me) 
	{
		mouseX = me.getX();
		mouseY = me.getY();
		msg = "Down";
		repaint();
	}

	// Handle button released.
	public void mouseReleased(MouseEvent me) 
	{
		mouseX = me.getX();
		mouseY = me.getY();
		msg = "Up";
		repaint();
	}

	// Display msg in applet window at current X,Y location.
	public void paint(Graphics g) 
	{
		g.drawString(msg, mouseX, mouseY);
	}
}
