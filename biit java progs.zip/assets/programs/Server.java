// File-1 : Server.java
// The Server Socket program.

import java.io.*;
import java.net.*;

public class Server 
{
	public static void main( String[ ] args ) 
	{
		try 
		{
			ServerSocket ss = new ServerSocket(5000);
			Socket sc = ss.accept( );
			
			InputStream is = sc.getInputStream();
			InputStreamReader isr = new InputStreamReader( is );
			BufferedReader in = new BufferedReader( isr );
			PrintWriter out = new PrintWriter(sc.getOutputStream(), true);
			String str = in.readLine();
			out.println(" Institute Name : " + str);
			sc.close();
		}
		catch (Exception e) 
		{ }
	}
}

// File-2 : Client.java
// The Client Socket Program.

import java.net.*;
import java.io.*;

class Client 
{
	public static void main( String args[ ] ) throws Exception 
	{
		int ch;
		// IP address of Server PC => 192.168.1.2
		Socket sc = new Socket("192.168.1.2", 5000);
		// Host name of Server PC => PC1
		// or Socket sc = new Socket("PC1", 5000);
		
		InputStream in = sc.getInputStream();
		OutputStream out = sc.getOutputStream();
		String str = "BIIT Computer Education.\n";
		byte buf[ ] = str.getBytes();
		out.write(buf);

		while ((ch = in.read()) != -1) 
		{
			System.out.print((char) ch);
		}
		sc.close();
	}
}
