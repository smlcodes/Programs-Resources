import java.awt.*;
import java.applet.*;

/*
<applet code="FillArcTest1a" width="200" height="100" >
</applet>
*/

public class  FillArcTest1a  extends  Applet  
{
	public void paint(Graphics g) 
	{
		setBackground( Color.yellow );
		g.fillArc(20, 20, 160, 60, 90, 90);  
	}
}
