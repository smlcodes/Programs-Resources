class A 
{
	int x;
}

class B extends A 
{
	int  x; 		// this x hides the x in A

	B(int a, int b) 
	{
		super.x = a; 		// x in A
		x = b; 			// x in B
	}

	void show() 
	{
		System.out.println("x in superclass: " + super.x);
		System.out.println("x in subclass: " + x);
	}
}

class  HideSuperClassVar 
{
	public static void main(String args[ ]) 
	{
		B ob = new B(1, 2);

		ob.show();
	}
}
