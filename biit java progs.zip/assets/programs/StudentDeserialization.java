import java.io.*;

class Student implements Serializable
{
	int rno;
	String sname;
	double marks;
		
	// Constructor
	Student( int r, String nm, double m )
	{
		rno = r;
		sname = nm;
		marks = m;
	}
	
	void display()
	{
		System.out.println(" Roll No. : " + rno );
		System.out.println(" Name : " + sname );
		System.out.println(" Marks : " + marks );
	}
	
	public static Student getData() throws IOException
	{		
		int r;
		String nm;
		double m;
		
		BufferedReader br = new BufferedReader( new InputStreamReader( System.in ));
		
		System.out.print(" Enter roll number : ");
		r = Integer.parseInt(br.readLine());
		
		System.out.print(" Enter name : ");
		nm = br.readLine();
		
		System.out.print(" Enter total marks : ");
		m = Double.parseDouble(br.readLine());
		
		// Creating Student object and initializing
		Student s = new Student(r, nm, m);
		return s;
	}
}

class StudentDeserialization
{
	public static void main( String args[ ] ) throws Exception
	{
		// attach FileInputStream to file.
		FileInputStream fis = new FileInputStream( "StuFile" );
		
		// attach ObjectInputStream to FileInputStream.
		ObjectInputStream ois = new ObjectInputStream( fis );
		
		// read object (s) from 'ois'
		Student s;
		s = (Student)ois.readObject();
		
		// Display student object (s)
		s.display();
		
		ois.close();		
	}
}
