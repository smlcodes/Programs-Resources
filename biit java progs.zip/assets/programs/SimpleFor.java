class  SimpleFor
{
	public static void main( String args[ ] )
	{
		int i, n;
		n = Integer.parseInt( args[0] );

		for( i=1 ; i<=n ; i++ )
		{
			System.out.print( "     " + i );
		}
	}
}
