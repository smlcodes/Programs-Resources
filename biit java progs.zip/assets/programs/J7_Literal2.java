class J7_Literal2
{
	public static void main( String args[ ] )
	{
		long dec = 1234_5678_9876_5432L;
		int hex = 0xE_23D5_8C_7;
		int bin = 0b1110_0010001111010101_10001100_0111;
		
		System.out.println("Dec number : " + dec);
		System.out.println("Hex number : " + hex);
		System.out.println("Bin number : " + bin);
	}
}
