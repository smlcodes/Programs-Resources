class  MtoString
{
	public static void main( String args[ ] )
	{
		StringBuffer sb = new StringBuffer( "BIIT Computer Education." );
		
		String s = sb.toString();

		System.out.println( " String = " + s );	
	}
}
