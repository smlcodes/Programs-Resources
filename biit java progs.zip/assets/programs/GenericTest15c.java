//  Overriding Methods in a Generic Class.

class  Gen<T> 
{ 
	T ob;
  
	Gen(T o) 
	{ 
		ob = o; 
	} 
 
	T getObject() 
	{ 
		System.out.println("Gen's getObject(): " );
		return ob; 
	} 
} 

class Gen2<T> extends  Gen<T> 
{
	Gen2(T o) 
	{
		super(o);
	}
  
	T getObject() 
	{ 
		System.out.println("Gen2's getObject(): ");
		return ob; 
	} 
}

public class GenericTest15c 
{
	public static void main(String[ ] args)
	{
		Gen<Integer> intObject = new Gen<Integer>(88); 
		Gen2<Long> longObject = new Gen2<Long>(99L);      
    
		intObject.getObject();
		longObject.getObject();
	} 
}
