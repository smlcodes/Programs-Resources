class  AreaCircle
{	
	public static void main( String args[ ] )
	{
		double rad;
		final double PI = 3.14159;

		rad = 10.0;

		double area = PI * rad * rad;
		System.out.print( "\n Area of Circle is = " + area );
	}
}
