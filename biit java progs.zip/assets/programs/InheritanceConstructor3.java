class  A 
{
	A(int a) 
	{
		System.out.println("A constructor. : " + a);
	}
}

class  B extends A 
{
	B(int a) 
	{
		super(a);
		System.out.println("B constructor.");
	}
}

class  C extends B 
{
	C() 
	{
		super(10);
		System.out.println("C constructor.");
	}
}

public class InheritanceConstructor3 
{
	public static void main(String[ ] args) 
	{
		C x = new C();
	}
}
