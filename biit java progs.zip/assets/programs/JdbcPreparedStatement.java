import java.sql.*;

class  JdbcPreparedStatement
{ 
	public static void main( String args[] ) 
	{ 
		int sid;
		String sname;
		String saddress;
		String sphone;
		String smobile;
		String res;

		String s = new String( args[0] );
		s = s.toUpperCase();

		try
		{
			Class.forName( "sun.jdbc.odbc.JdbcOdbcDriver" );
			String url = "jdbc:odbc:stuDSN";						
			Connection cn = DriverManager.getConnection( url, "username", "password" );
			cn.setAutoCommit( false );
			String qry = "select id, name, address, phone, mobile from student where name = ?";
			PreparedStatement pst = cn.prepareStatement( qry );		
			pst.setString( 1, s );
			
			ResultSet rs = pst.executeQuery();	
			
			while( rs.next() )	
			{
				res = " ";
				sid = rs.getInt( 1 );
				sname = rs.getString( 2 );
				saddress = rs.getString( 3 );
				sphone = rs.getString( 4 );
				smobile = rs.getString( 5 );
				res = String.valueOf( sid ) + "\t" + sname  + "\t" + saddress + "\t" + sphone + "\t" + smobile ;
				System.out.println( " Values are ::: " + res );
			}
			cn.commit();
			cn.close();
		}
		catch( Exception e )
		{
			System.out.println( e.getMessage() ); 
		}
	} 
} 
