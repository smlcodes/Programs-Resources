import java.awt.*;
import java.awt.event.*;
import java.applet.*;

/*
<applet  code="MouseMotionEventTest" width="300" height="200">
</applet>
*/

public class MouseMotionEventTest extends Applet implements MouseMotionListener 
{
	String msg = "";
	int mouseX = 0, mouseY = 0; 

	public void init() 
	{
		addMouseMotionListener(this);
	}
	
	// Handle mouse dragged.
	public void mouseDragged(MouseEvent me) 
	{
		mouseX = me.getX();
		mouseY = me.getY();
		msg = "*";
		showStatus("Dragging mouse at " + mouseX + ", " + mouseY);
		repaint();
	}
	
	// Handle mouse moved.
	public void mouseMoved(MouseEvent me) 
	{
		showStatus("Moving mouse at " + me.getX() + ", " + me.getY());
	}
	
	// Display msg in applet window at current X,Y location.
	public void paint(Graphics g) 
	{
		g.drawString(msg, mouseX, mouseY);
	}
}
