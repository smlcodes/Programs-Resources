package  Pack1;

public class  First
{
	public void view( )
	{
		System.out.println( "This is Test Package." );
	}
}

Second File [ ImportPack1.java ](in current folder) : 
import Pack1.*;

public class  ImportPack1
{
	public static void main( String args[ ] )
	{
		First f = new First();
		f.view();
	}
}
