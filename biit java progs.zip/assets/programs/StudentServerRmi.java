// [ IStudentRmi.java ] : 
import java.rmi.*;

interface  IStudentRmi  extends  Remote
{
	public String  getNameByRno( int rn ) 
throws RemoteException, Exception;
}

// [ StudentServerRmi.java ] : 
import java.rmi.*;
import java.rmi.server.*;
import java.sql.*;

public class StudentServerRmi extends UnicastRemoteObject  implements  IStudentRmi
{
	Connection cn; 
	Statement st; 
	ResultSet rs; 
	String nm = "", qry = "";
	
	public StudentServerRmi() throws RemoteException, Exception
	{  
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		String url = "jdbc:odbc:OracleDSN";

		cn = DriverManager.getConnection(url, "system", "tiger");		
	}

	public static void main( String args[ ] ) throws Exception
	{
		System.out.println( "Server Starts..." );
		StudentServerRmi s = new StudentServerRmi();
		Naming.rebind( "DBServerRMI", s );
	}

	public String getNameByRno( int rn ) throws RemoteException, Exception
	{
		qry = "SELECT Sname FROM studentstb where Rno=" + rn;
		st = cn.createStatement();
		rs = st.executeQuery(qry);
		if(rs.next()) 
		{
			nm = rs.getString(1);
		}
		else
		{
			nm = "NULL";
		}
		return nm;
	}
}

// [ StudentClientRmi.java ] : 
import java.io.*;
import java.rmi.*;
import java.net.*;

public class StudentClientRmi
{
	public static void main( String args[ ] ) throws Exception
	{	
		InputStreamReader isr = new InputStreamReader( System.in );
		BufferedReader br = new BufferedReader( isr );
		InetAddress ia = InetAddress.getLocalHost();

		String ip = ia.toString().substring( ia.toString().indexOf( '/' )+1);
		String url = "rmi://" + ip + "/DBServerRMI";

		System.out.println( " Remote Method Invocation ::: " );
		IStudentRmi m = (IStudentRmi) Naming.lookup( url );
		
		System.out.print( " Enter Roll Number : " );
		int r = Integer.parseInt( br.readLine() );

		System.out.println( " Name : " + m.getNameByRno( r ));
	}
}
