class  MString4
{
	public static void main( String args[ ] )
	{
		char ch[ ] = { 'B', 'I', 'I', 'T' };
		String s1 = new String( ch );	

		byte b[ ] = { 65, 66, 67, 68, 69, 70 };
		String s2 = new String( b );

		System.out.println( " String = " + s1 );
		System.out.println( " String = " + s2 );
	}
}
