import java.awt.*;
import java.applet.Applet;

/*
<applet code="AppletTest2a.class" width="300" height="100">
</applet>
*/

public class AppletTest2a  extends  Applet 
{
	public void init() 
	{
		System.out.println("width =" + getParameter("width"));
		System.out.println("height=" + getParameter("height"));
	}
}
