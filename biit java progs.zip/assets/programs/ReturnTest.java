class ReturnTest
{
	public static void main( String args[] )
	{
		int a = 10;
		System.out.println( "AAA" );
		if( a == 10 )
			return;
		System.out.println( "BBB" );
	}
}
