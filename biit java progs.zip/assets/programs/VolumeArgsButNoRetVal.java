import java.util.*;

public class  VolumeArgsButNoRetVal 
{
	public static void main( String args[ ] )
	{
		double r, h;
		Scanner sc = new Scanner( System.in );
		
		System.out.print("Enter Radius : ");
		r = sc.nextDouble();
		System.out.print("Enter Height : ");
		h = sc.nextDouble(); 

		CylinderVolume(r, h);
	}

	static void CylinderVolume(double r, double h)
	{
		double v;	
		final double PI = 3.14;
		
		v = PI * r * r * h;
		
		System.out.println("Volume of Cylinder : " + v);
	}
}
