class ABC
{
	ABC()
	{
		System.out.println( "Object is created." );
	}
}

class XYZ 
{
	XYZ()
	{
		System.out.println( "Object is created." );
	}
}

public class OpInstanceOf
{
	public static void main( String args[ ] )
	{
		ABC a = new ABC();

		if( a  instanceof  ABC )
		{
			System.out.println( "a is an instance of class ABC." );
		}
		else
		{
			System.out.println( "a is not an instance of class ABC." );
		}

		if( a  instanceof  XYZ )
		{
			System.out.println( "a is an instance of class XYZ." );
		}
		else
		{
			System.out.println( "a is not an instance of class XYZ." );
		}
	}
}
