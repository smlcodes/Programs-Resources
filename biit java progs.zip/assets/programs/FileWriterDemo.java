import java.io.*;

class FileWriterDemo
{
	public static void main( String args[ ] ) throws IOException
	{
		// attach DataInputStream to keyboard.
		DataInputStream dis = new DataInputStream( System.in );
		
		// attach file to FileWriter
		FileWriter fw = new FileWriter( "file1.txt");
		
		// read characters from keyboard and write it to file.
		char ch;
		System.out.println(" Enter string ( $ to end ) : ");
		while( (ch = (char)dis.read()) != '$' )
		{
			fw.write( ch );
		}

		// close the file.
		fw.close();
	}
}
