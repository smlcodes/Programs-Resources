import java.awt.*;
import java.awt.event.*;
import java.applet.*;

/*
<applet code="FlowLayoutDemo" width="300" height="150">
</applet>
*/

public class FlowLayoutDemo extends Applet 
{
	Button b1, b2, b3, b4, b5;

	public void init() 
	{
		setLayout(new FlowLayout(FlowLayout.LEFT));

		b1 = new Button("Button-1");
		b2 = new Button("Button-2");
		b3 = new Button("Button-3");
		b4 = new Button("Button-4");
		b5 = new Button("Button-5");

		add(b1);
		add(b2);
		add(b3);
		add(b4);
		add(b5);
	}
}
