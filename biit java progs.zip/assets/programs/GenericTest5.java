class  Gen 
{
	private double val;

	//  Generic constructor.
	<T extends Number> Gen(T arg) 
	{
		val = arg.doubleValue();
	}

	void showValue() 
	{
		System.out.println("val: " + val);
	}
}

public class  GenericTest5
{
	public static void main(String args[ ]) 
	{
		Gen t1 = new Gen(100);
		Gen t2 = new Gen(123.5F);

		t1.showValue();
		t2.showValue();
	}
}
