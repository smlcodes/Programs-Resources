import java.awt.*;
import java.applet.*;

/*
<applet code="DrawLineTest1a" width="200" height="100" >
</applet>
*/

public class DrawLineTest1a  extends  Applet  
{
	public void paint(Graphics g) 
	{
		setBackground( Color.yellow );
		g.drawLine(20, 20, 180, 80);
	}
}
