class  Mdelete
{
	public static void main( String args[ ] )
	{
		StringBuffer sb = new StringBuffer( "BIIT Computer Education." );

		System.out.println( " String = " + sb );
		
		sb = sb.delete( 5, 14 );

		System.out.println( " String = " + sb );
	}
}
