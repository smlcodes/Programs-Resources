import static java.lang.Math.*;
//   import static java.lang.Math.sqrt;

class StaticImport
{
	public static void main( String args[ ] )
	{
		double a = 3.0, b = 4.0;
		double c = sqrt( a*a + b*b );
		System.out.println(" C = " + c );
	}
}
