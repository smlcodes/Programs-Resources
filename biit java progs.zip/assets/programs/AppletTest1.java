import java.applet.Applet;
import java.awt.*;

/*
<applet  code="AppletTest1.class" width="300" height="100">
</applet>
*/

public class AppletTest1 extends  Applet 
{
	String msg = "";
	
	public void init() 
	{
		setBackground( Color.yellow );
		msg = "init() ->";
	}

	public void start() 
	{
		msg += "start() ->";
	}
	
	public void paint( Graphics g ) 
	{
		msg += "paint() ->";
		g.drawString(msg, 50, 50);
	}
}
