import java.awt.*;
import java.applet.*;

/*
<applet code="FillRoundRectTest1a" width="200" height="100" >
</applet>
*/

public class FillRoundRectTest1a  extends  Applet  
{
	public void paint(Graphics g) 
	{
		setBackground( Color.yellow );
		g.fillRoundRect (15, 15, 165, 65, 40, 30);  
	}
}
