class  Msubstring
{
	public static void main( String args[ ] )
	{
		String s1 = "BIIT Computer Education.";	
		
		String s2 = s1.substring( 5 );
		String s3 = s1.substring( 5, 13 );

		System.out.println( " Source : " + s1 );
		System.out.println( " Target : " + s2 );
		System.out.println( " Target : " + s3 );
	}
}
