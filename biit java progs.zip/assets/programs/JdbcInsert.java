import java.sql.*;

class  JdbcInsert
{ 
	public static void main( String args[] ) 
	{ 
		try
		{
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver" );
			String url = "jdbc:odbc:DSNName";			
			Connection cn = DriverManager.getConnection(url, "username", "password" );
			cn.setAutoCommit( false );
			Statement st = cn.createStatement();					
			String qry = "insert into student (id, name, address, phone, mobile) values( 108, 'SUYASH', 'MARODA', '9999999', '22222-11111')";	
			int cnt = st.executeUpdate( qry );
			System.out.println( "Insert Row : " + qry.valueOf( cnt ) );
						
			cn.commit();
			cn.close();
		}
		catch( Exception e )
		{
			System.out.println( e.getMessage() ); 
		}
	} 
} 
