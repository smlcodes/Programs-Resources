public class  StaticMethodClass
{
	public static void main( String  args[ ] )
	{ 
		A.displayMsg(); 
	}
}

class  A
{
	public static void displayMsg()
	{
		System.out.println( "Welcome to BIIT !!!" );
	}
}
