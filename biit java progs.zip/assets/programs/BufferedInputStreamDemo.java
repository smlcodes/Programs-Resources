import java.io.*;

class  BufferedInputStreamDemo 
{
	public static void main( String args[ ] ) throws IOException
	{
		// attach the file to FileInputStream
		FileInputStream fis = new FileInputStream("file1.txt");
		BufferedInputStream bis = new BufferedInputStream( fis );
		
		System.out.println(" File contents are : ");
		// Read character from fis and write them to monitor.
		int ch;
		while( (ch=bis.read()) != -1 )
		{
			System.out.print( (char)ch );
		}
		
		// close the file
		fis.close();
	}
}
