class Box 
{
	private double width;
	private double height;
	private double depth;
	
	void initBox(double w, double h, double d)
	{
		width = w;
		height = h;
		depth = d;
	}
	
	double volume() 
	{
		return width * height * depth;
	}
}

class  BoxTest6
{
	public static void main(String args[ ]) 
	{
		Box b1 = new Box();
		Box b2 = new Box();
		
		b1.initBox(10, 15, 20);
		
		b2.initBox(5, 6, 7);
		
		System.out.println("Volume is " + b1.volume());
		System.out.println("Volume is " + b2.volume());
	}
}
