class Box 
{
	private double width;
	private double height;
	private double depth;
	
	Box()
	{
		width = 10;
		height = 10;
		depth = 10;
	}
	
	double volume() 
	{
		return width * height * depth;
	}
}

class  BoxTest7 
{
	public static void main(String args[ ]) 
	{
		Box b1 = new Box();
		Box b2 = new Box();
		
		System.out.println("Volume is " + b1.volume());
		System.out.println("Volume is " + b2.volume());
	}
}
