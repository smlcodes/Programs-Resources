class  Circle
{
	private double radius;
	
	Circle()
	{
		radius = 0.0;
	}
	
	Circle( double radius)
	{
		this.radius = radius;
	}
	
	public double area()
	{
		return 3.14 * radius * radius;
	}
} 

public class CircleReturningObject
{
	public static void main( String args[ ] )
	{ 
		Circle c1;
		
		c1 = createCircle();
		calcArea( c1 );
	}
	
	public static Circle createCircle()
	{
		Circle c = new Circle( 10 );
		return  c;
	}
	
	public static void calcArea( Circle c )
	{
		System.out.println(" Area of Circle : " + c.area()); 
	}
}
