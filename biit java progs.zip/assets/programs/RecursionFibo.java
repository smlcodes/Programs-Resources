class  RecursionFibo
{
	public static void main(String[ ] args) 
	{
		int n = 5, t;
		t = fibonacci( n );
		System.out.println(" " + n + "th term of Fibonacci Series : " + t);
	}
	
	public static int fibonacci( int n ) 
	{
		if(n == 0 || n == 1)
			return n;
		else
			return ( fibonacci(n-1) + fibonacci(n-2) );
	}
}
