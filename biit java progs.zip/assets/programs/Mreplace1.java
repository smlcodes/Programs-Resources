class  Mreplace1
{
	public static void main( String args[ ] )
	{
		StringBuffer sb = new StringBuffer( "BIIT Computer Education." );

		System.out.println( " String = " + sb );
		
		sb = sb.replace( 5, 13, "Technical" );

		System.out.println( " String = " + sb );
	}
}
