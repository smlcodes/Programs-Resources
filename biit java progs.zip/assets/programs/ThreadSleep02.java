class NewThread implements Runnable
{
 	Thread t;
 
	NewThread()
 	{
  		t = new Thread( this, "Demo Thread" );
  		System.out.println( "Child thread ::: " + t );
  		t.start();
 	}
 
 	public void run()
 	{
  		try
		{
			for( int i=10 ; i>0 ; i-- )
			{
				System.out.println( "Child Thread = " + i );
				Thread.sleep( 500 );
			}
      	}
		catch( InterruptedException e )
		{
			System.out.println( "Child interrupted." );
		}
		System.out.println( "Exiting child thread." );
	}
}

class ThreadSleep02 
{
	public static void main( String args[ ] )
	{
		new NewThread();

		try
		{
			for( int i=10 ; i>0 ; i-- )
			{
				System.out.println( "Main Thread = " + i );
				Thread.sleep( 500 );
			}
		}
		catch( InterruptedException e )
		{
           	System.out.println( "Main Thread Interrupted." );
		}
		System.out.println( "Main Thread Exiting." );
	}
}
