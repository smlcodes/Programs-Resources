interface A
{
	void showA();
}

class  B  implements  A
{
	public void showA()
	{
		System.out.println("showA() of A interface  in B.");
	}
}

class  C  implements  A
{
	public void showA()
	{
		System.out.println("showA() of A interface  in C.");
	}
}

class  InterfaceTest7
{
	public static void main( String args[ ] )
	{
		A a1;
		
		a1 = new  B();
		a1.showA();
		
		a1 = new  C();
		a1.showA();
	}
}
