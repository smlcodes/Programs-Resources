import java.awt.*;
import java.applet.*;

/*
	<applet code="Applet04" width="300" height="50">
	</applet>
*/

public class Applet04 extends  Applet
{
	public void init() 
	{
		setBackground(Color.yellow);
	}

	public void paint(Graphics g) 
	{
		g.drawString("BIIT Computer Education.", 10, 20);
		showStatus("This is shown in the status window.");
	}
}
