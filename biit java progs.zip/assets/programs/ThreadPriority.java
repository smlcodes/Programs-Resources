class A extends Thread
{
	public void run()
	{
		for( int i=1 ; i<=15 ; i++ )
		{
		     	System.out.println( " THREAD A = " + i );
		}
		System.out.println( " END OF THREAD A." );
	}
}

class B extends Thread
{
	public void run()
	{
		for( int j=1 ; j<=15 ; j++ )
		{
		     	System.out.println( " THREAD B = " + j );
		}
		System.out.println( " END OF THREAD B." );
	}
}	

class ThreadPriority
{
	public static void main( String args[ ] )
	{
		A a = new A();
		B b = new B();
	
		a.setPriority( Thread.MAX_PRIORITY - 2 );
		b.setPriority( Thread.MIN_PRIORITY + 2 );

		a.start();
		b.start();	

		System.out.println( " END OF MAIN THREAD." );
	}
}
