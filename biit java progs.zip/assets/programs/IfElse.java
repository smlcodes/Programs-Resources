class IfElse
{
	public static void main( String args[ ] )
	{
		int  n;
		
		n = Integer.parseInt( args[0] );

		if( n > 100 )
		{
			System.out.println( " The number is greater than 100." );
		}	
		else
		{
			System.out.println( " The number is smaller than 100." );
		}
	}
}
