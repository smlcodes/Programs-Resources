class  MsetLength
{
	public static void main(String args[ ])
	{
		StringBuffer sb1 = new StringBuffer("BIIT Computer Education.");
		System.out.println(" String = " + sb1);

		sb1.setLength(13);

		System.out.println(" String = " + sb1);	

		sb1.setLength(4);

		System.out.println(" String = " + sb1);	
	}
}
