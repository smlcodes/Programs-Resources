import java.io.*;

class  Swap3
{
	public static void main( String args[ ] ) throws IOException
	{
		int  a=0, b=0, t;

		DataInputStream dis = new DataInputStream(System.in );
		
		System.out.print(" Enter first Number : ");
		a = Integer.parseInt(dis.readLine());
		System.out.print(" Enter second Number : ");
		b = Integer.parseInt(dis.readLine());
	
		System.out.print( "\n Before Swapping : " );
		System.out.print( a + "   " + b );

		a = a + b;
		b = a - b;
		a = a - b;
		
		System.out.print( "\n After Swapping  : " );
		System.out.print( a + "   " + b );
	}
}
