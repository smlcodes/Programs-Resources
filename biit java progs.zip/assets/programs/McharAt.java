class  McharAt
{
	public static void main( String args[ ] )
	{
		char ch;
		String s1 = "BIIT";	
		
		ch = s1.charAt( 0 );
		System.out.println( " Character at 0 : " + ch );

		ch = "BIIT".charAt( 3 );
		System.out.println( " Character at 3 : " + ch );
	}
}
