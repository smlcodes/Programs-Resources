class  MtoUpperCase
{
	public static void main( String args[ ] )
	{
		String s1 = "BIIT Computer Education.";
		String s2 = s1.toUpperCase();

		System.out.println( " Original  String : " + s1 );
		System.out.println( " UpperCase String : " + s2 );
	}
}
