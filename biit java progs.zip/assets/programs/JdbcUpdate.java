import java.sql.*;

class  JdbcDelete
{ 
	public static void main( String args[] ) 
	{ 
		String qry;

		int n = Integer.parseInt( args[0] );

		try
		{
			Class.forName( "sun.jdbc.odbc.JdbcOdbcDriver" );	
			String url = "jdbc:odbc:DSN_Name";			
			Connection cn = DriverManager.getConnection(url, "username", "password" );
			cn.setAutoCommit( false );
			Statement st = cn.createStatement();		
			qry = "delete from student where id=" + n;				
			int cnt = st.executeUpdate( qry );
			System.out.println( "Deleted Rows : " + qry.valueOf( cnt ) );

			cn.commit();
			cn.close();
		}
		catch( Exception e )
		{
			System.out.println( e.getMessage() ); 
		}
	} 
} 
