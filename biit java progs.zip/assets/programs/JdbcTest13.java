import java.sql.*;

public class  JdbcTest13
{
	public static void main(String[ ] args) throws Exception 
	{
		int rno = 0, age = 0;
		String name = "", address = "";
		String qry = "";
		
		rno = Integer.parseInt(args[0]);
		
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		String url = "jdbc:odbc:OracleDSN";

		Connection cn = DriverManager.getConnection(url, "system", "tiger");
		CallableStatement cst = cn.prepareCall("{?=Call ShowSNameByRno(?)}");
		
		cst.setInt(2, rno);				
		cst.registerOutParameter(1, Types.VARCHAR);
		
		cst.execute();
		
		String nm = cst.getString(1);		
		System.out.println("Student Name = " + nm );
		
		cst.close();
		cn.close();
	}
}

(Stored Procedure in Oracle) : 
create or replace function ShowSNameByRno( a number ) 
     return varchar2
as
	n varchar2(25);
begin
	select sname into n from studentstb where rno = a;
	return n;
end;
