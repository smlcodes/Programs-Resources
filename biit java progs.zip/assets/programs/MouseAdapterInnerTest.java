import java.applet.*;
import java.awt.event.*;

/*
<applet code="MouseAdapterInnerTest" width="300" height="100">
</applet>
*/

public class MouseAdapterInnerTest extends Applet 
{
	public void init() 
	{
		addMouseListener(new MyMouseAdapter());
	}
	
	class MyMouseAdapter extends MouseAdapter 
	{
		public void mouseClicked(MouseEvent me) 
		{
			showStatus("Mouse Clicked.");
		}
	}
}
