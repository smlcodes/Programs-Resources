class  A
{
	final void display()
	{
		System.out.println(" A\'s display().");
	}
}

class  B extends A
{
	// final method can't be override.
	// void display()
	void show()
	{
		System.out.println(" B\'s display().");
	}
}

class  FinalMethod
{
	public static void main( String args[ ] )
	{
		B b = new B();
		b.display();
		b.show();
	}
}
