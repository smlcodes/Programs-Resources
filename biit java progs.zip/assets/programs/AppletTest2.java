import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.applet.Applet;
import java.awt.Button;

/*
<applet code="AppletTest2.class" width="300" height="100">
</applet>
*/

public class AppletTest2 extends Applet 
{
	Button b1 = new Button("Click Here");

	public void init() 
	{
		b1.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				System.out.println("Button was clicked");
			}
		});

		add(b1);
	}
}
