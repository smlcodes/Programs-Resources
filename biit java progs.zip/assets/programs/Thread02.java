class A extends Thread
{
	public A( String s )
	{
		super(s);
	}

	public void run()
	{
		for( int i=1 ; i<=15 ; i++)
		{
			System.out.println( getName() );
		}
	}
}

class Thread02
{
	public static void main( String args[ ] )
	{
		new A( "BIIT" ).start();
		new A( "Computer" ).start();
		new A( "Education" ).start();

		System.out.println(" Hello !!! ");
	}
}
