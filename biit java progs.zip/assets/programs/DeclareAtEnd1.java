class  DeclareAtEnd1
{
	public static void main( String args[ ] )
	{
		DeclareAtEnd1 ob = new DeclareAtEnd1();
		ob.msg = "Let's learn JAVA !";
        System.out.println("Message : " + ob.msg);
	}
	
	String msg;
}
