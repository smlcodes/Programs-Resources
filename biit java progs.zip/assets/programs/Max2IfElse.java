class Max2IfElse
{
	public static void main( String args[] )
	{
		int a, b, max;

		a = Integer.parseInt( args[0] );
		b = Integer.parseInt( args[1] );

		if( a > b )
			max = a;
		else
			max = b;
	    
		System.out.println("\nMaximum : " + max );
	}
}
