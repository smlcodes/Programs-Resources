class   A<T> 
{
	T ob;

	A(T o) 
	{
		ob = o;
	}

	T getob() 
	{
		return ob;
	}

	void showType() 
	{
		System.out.println("Type of T is " + ob.getClass().getName());
	}
}

public class  GenericTest1
{
	public static void main(String args[ ]) 
	{
		A<Integer> iOb = new A<Integer>(100);
		iOb.showType();

		int v = iOb.getob();
		System.out.println("Value: " + v);

		System.out.println();
		A<String> strOb = new A<String>("BIIT");
		strOb.showType();

		String str = strOb.getob();
		System.out.println("Value: " + str);
	}
}
