import java.awt.*;
import java.awt.event.*;
import java.applet.*;

/*
<applet code="CheckBoxDemo" width="250" height="150">
</applet>
*/

public class CheckBoxDemo extends Applet implements ItemListener 
{
	String msg = "";
	Checkbox cbRed, cbGreen, cbBlue;

	public void init() 
	{
		cbRed = new Checkbox("Red", null, true);
		cbGreen = new Checkbox("Green");
		cbBlue = new Checkbox("Blue");
		
		add(cbRed);
		add(cbGreen);
		add(cbBlue);
		
		cbRed.addItemListener(this);
		cbGreen.addItemListener(this);
		cbBlue.addItemListener(this);
	}
	
	public void itemStateChanged(ItemEvent ie) 
	{
		repaint();
	}

	public void paint(Graphics g) 
	{
		msg = "Color Selection: ";
		g.drawString(msg, 6, 80);
		msg = " Red: " + cbRed.getState();
		g.drawString(msg, 6, 100);
		msg = " Green: " + cbGreen.getState();
		g.drawString(msg, 6, 120);
		msg = " Blue: " + cbBlue.getState();
		g.drawString(msg, 6, 140);
	}
}
