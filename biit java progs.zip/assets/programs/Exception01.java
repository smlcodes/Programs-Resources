class  Exception01 
{
	public static void main(String args[ ]) 
	{
		int  d = 0;
		int  a = 10 / d;
	}
}
