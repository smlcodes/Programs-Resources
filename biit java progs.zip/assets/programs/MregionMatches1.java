class  MregionMatches1 
{
	public static void main(String args[ ])
	{
		boolean b;
		String s1 = new String("BIIT Computer Education.");
		String s2 = new String("Computer");

		b = s1.regionMatches(5, s2, 0, 8);

		//  For ignore case.
		//  b = s1.regionMatches(true, 5, s2, 0, 8);

		System.out.print(" Result of Region Match : " + b);
	}
}
