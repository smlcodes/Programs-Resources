import java.sql.*;

class  JdbcSelect
{ 
	public static void main( String args[ ] ) 
	{ 
		int sid;
		String sname;
		String saddress;
		String sphone;
		String smobile;
		String res;

		try
		{
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver" );
			String url = "jdbc:odbc:DSNName";					
			Connection cn = DriverManager.getConnection(url, "username", "password" );
			Statement st = cn.createStatement();
			String qry = "select id, name, address, phone, mobile from student";		
			ResultSet rs = st.executeQuery( qry );		
	
			while( rs.next() )	
			{
				res = " ";
				sid = rs.getInt( 1 );
				sname = rs.getString( 2 );
				saddress = rs.getString( 3 );
				sphone = rs.getString( 4 );
				smobile = rs.getString( 5 );
				res = String.valueOf( sid ) + "\t" + sname + "\t" + saddress + "\t" + sphone + "\t" + smobile ;
				System.out.println(" Values are ::: " + res );
			}
			cn.close();
		}
		catch( Exception e )
		{
			System.out.println(	e.getMessage() ); 
		}
	} 
} 
