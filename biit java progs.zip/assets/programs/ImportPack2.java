package  Pack1;

class First
{
	public void view( )
	{
		System.out.println( "This is Test Package." );
	}
}

public class  ImportPack2
{
	public static void main( String args[ ] )
	{
		First f = new First();
		f.view();
	}
}
