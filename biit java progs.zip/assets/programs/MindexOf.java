class  MindexOf
{
	public static void main(String args[ ])
	{
		String s1 = "BIIT Computer Education BIIT Computer Education.";
				
		System.out.println(" Index of " + 'C' + " = " + s1.indexOf('C'));
		System.out.println(" Index of " + 'x' + " = " + s1.indexOf('x'));
		System.out.println(" Index of " + "Computer" + " = " + s1.indexOf("Computer"));
		System.out.println(" Index of " + "COMPUTER" + " = " + s1.indexOf("COMPUTER"));
	}
}
