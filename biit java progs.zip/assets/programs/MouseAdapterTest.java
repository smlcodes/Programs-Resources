import java.applet.*;
import java.awt.event.*;

/*
<applet code="MouseAdapterTest" width="200" height="100">
</applet>
*/

public class MouseAdapterTest extends Applet 
{
	public void init() 
	{
		addMouseListener(new MyMouseAdapter(this));
	}
}

class MyMouseAdapter extends MouseAdapter 
{
	MouseAdapterTest   mat;
	
	public MyMouseAdapter(MouseAdapterTest   m) 
	{
		this.mat = m;
	}
	
	public void mouseClicked(MouseEvent  me) 
	{
		mat.showStatus("Mouse Clicked.");
	}
}
