class  MtoLowerCase
{
	public static void main( String args[ ] )
	{
		String s1 = "BIIT Computer Education.";
		String s2 = s1.toLowerCase();

		System.out.println( " Original  String : " + s1 );
		System.out.println( " LowerCase String : " + s2 );
	}
}
