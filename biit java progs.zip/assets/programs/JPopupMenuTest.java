import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class JPopupMenuTest 
{
	JLabel lbl;
	
	public JPopupMenuTest()
	{
		JFrame f = new JFrame("Popup Example");
		f.setLayout(new BorderLayout());
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		// Create popup menu, attach popup menu listener
		JPopupMenu pMenu = new JPopupMenu("Title");
		lbl = new JLabel();
		
		// Cut
		JMenuItem mnuCut = new JMenuItem("Cut");
		pMenu.add(mnuCut);

		// Copy
		JMenuItem mnuCopy = new JMenuItem("Copy");
		pMenu.add(mnuCopy);

		// Paste
		JMenuItem mnuPaste = new JMenuItem("Paste");
		mnuPaste.setEnabled(false);
		pMenu.add(mnuPaste);

		// Separator
		pMenu.addSeparator();

		// Find
		JMenuItem mnuFind = new JMenuItem("Find");
		pMenu.add(mnuFind);

		JButton btn = new JButton("Right Click Me");
		f.add(btn, BorderLayout.NORTH);
		
		btn.setComponentPopupMenu(pMenu);

		mnuCut.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				lbl.setText("Cut Popup Menu Item Clicked");
			}
		});

		f.add(lbl, BorderLayout.SOUTH);
		f.setSize(250, 150);
		f.setVisible(true);
	}	
	
	public static void main(String args[ ]) 
	{
		new JPopupMenuTest();
	}
}
