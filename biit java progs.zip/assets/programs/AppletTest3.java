import java.awt.*;
import java.applet.Applet;

/*
<applet  code="AppletTest3.class" width="300" height="60">
	<param name="msg" value="Let's learn Applet.">  
</applet>
*/

public class AppletTest3 extends Applet 
{
	String msg = "";
	
	public void init() 
	{
		setBackground( Color.yellow );
		msg = getParameter("msg");
	}
	
	public void paint( Graphics g ) 
	{
		System.out.println(msg);
		g.drawString(msg, 50, 30);
	}
}

HTML Source Code [ AppletTest3.html ] : 
<html>  
	<head>  
		<title>BIIT</title>  
	</head>
  
	<body>
		<applet code="AppletTest3.class" width="300" height="60">  
			<param name="msg" value="Let's learn Applet.">  
		</applet>  
		<hr size="4">  
	</body>  
</html>
