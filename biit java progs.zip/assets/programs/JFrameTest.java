import javax.swing.JFrame;

public class JFrameTest  extends  JFrame 
{
	public JFrameTest()
	{
		setSize(300, 150);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Let's learn Swing");
		setVisible(true);
	}
	
	public static void main(String[ ] args) 
	{
		JFrameTest f = new JFrameTest();
	}
}
