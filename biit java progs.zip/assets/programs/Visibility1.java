First File [ Derived.java ] : 
package p1;

public class Base 
{
	private int n_pri = 1;
	int n_def = 2;
	protected int n_pro = 3;
	public int n_pub = 4;

	public Base() 
	{
		System.out.println("base constructor");
		System.out.println("n_pri = " + n_pri);
		System.out.println("n_def = " + n_def);
		System.out.println("n_pro = " + n_pro);
		System.out.println("n_pub = " + n_pub);
	}
}

Second File [ Derived.java ] : 
package  p1;

class  Derived  extends  Base 
{
	Derived() 
	{
		System.out.println("derived constructor");
		// class only
		// System.out.println("n_pri = "4 + n_pri);
		System.out.println("n_def = " + n_def);
		System.out.println("n_pro = " + n_pro);
		System.out.println("n_pub = " + n_pub);
	}
}

Third File [ SamePackage.java ] : 
package  p1;

class  SamePackage 
{
	SamePackage() 
	{
		Base b = new Base();
		System.out.println("same package constructor");
		// class only
		// System.out.println("n_pri = " + b.n_pri);
		System.out.println("n_def = " + b.n_def);
		System.out.println("n_pro = " + b.n_pro);
		System.out.println("n_pub = " + bl.n_pub);
	}
}

Fourth File [ Demo.java ] : 
package  p1;

// Instantiate the various classes in p1.
public class  Demo 
{
	public static void main(String args[ ]) 
	{
		Base ob1 = new Base();
		Derived ob2 = new Derived();
		SamePackage ob3 = new SamePackage();
	}
}
