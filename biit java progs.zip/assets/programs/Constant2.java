class MyConstant
{
	public static final int NUMBER_OF_MONTHS = 12;
	public static final double PI = (double) 22 / 7;
}

class Constant2
{
	public static void main( String args[ ] )
	{
		System.out.println("NUMBER_OF_MONTHS : " + MyConstant.NUMBER_OF_MONTHS );
		System.out.println("PI : " + MyConstant.PI );
	}
}
