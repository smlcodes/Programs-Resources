interface A
{
	int  SIZE = 100;
	void  showA();
}

class Test  implements  A
{
	public void showA()
	{
		System.out.println("showA() of A interface.");
		System.out.println("SIZE = " + SIZE);
	}
}

class  InterfaceTest2
{
	public static void main( String args[ ] )
	{
		A  a1 = new Test();
		a1.showA();
	}
}
