class NewThread implements Runnable
{
	String tn;
	Thread t;

	NewThread( String tname )
	{
		tn = tname;
		t = new Thread( this, tn );
		System.out.println( " New Thread ::: " + t );
		t.start();
	}

	public void run()
	{
		try
		{
			for( int i=1 ; i<=10 ; i++ )
			{
				System.out.println( tn + " ::: " + i );
				Thread.sleep( 200 );
			}
		}
		catch( InterruptedException e )
		{  }
		System.out.println( tn + " Finishing ... " );
	}
}

public class SuspendResumeDemo 
{
	public static void main( String args[ ] )
	{
		NewThread ob1 = new NewThread( "ONE" );
		NewThread ob2 = new NewThread( "TWO" );
		try
		{
			Thread.sleep( 500 );
			ob1.t.suspend();
			System.out.println( " Thread ONE is Suspended." );
			Thread.sleep( 500 );
			ob1.t.resume();
			System.out.println( " Thread ONE is Resumed." );
			Thread.sleep( 500 );
			ob2.t.suspend();
			System.out.println( " Thread TWO is Suspended." );
			Thread.sleep( 500 );
			ob2.t.resume();
			System.out.println( " Thread TWO is Resumed." );

			System.out.println( " Waiting for threads to finish." );		
			ob1.t.join();
			ob2.t.join();
		}
		catch( InterruptedException e )
		{  }
		System.out.println( " Finishing Main Thread." );
    }
}
