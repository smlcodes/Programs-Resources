class  Mfloor
{
	public static void main( String args[ ] )
	{
		double n = Math.floor( 5.9995d );
		System.out.println( " Value : " + n );
	}
}
