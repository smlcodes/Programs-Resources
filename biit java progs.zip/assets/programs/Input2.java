import java.io.*;

class Input2
{
	public static void main( String args[ ] )
	{
		Console cn = System.console();
		int n;
		
		System.out.print( "Enter a Number : ");
		n = Integer.parseInt( cn.readLine() );

		System.out.println( "The given number : " + n );
	}
}
