class  Days
{
	public static void main( String args[ ] )
	{
	  	int  days, years, months, weeks;
  	
		days = Integer.parseInt( args[0] );

		years = days / 365;
  		days = days % 365;
  		months = days / 30;
		days = days % 30;
		weeks = days / 7;
		days = days % 7;
  	
		System.out.print("\n Years  = " + years );
  		System.out.print("\n Months=" + months );
	  	System.out.print "\n Weeks = " + weeks );
		System.out.print( "\n Days   = " + days );
	}
}
