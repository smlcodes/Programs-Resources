import java.sql.*;

public class JdbcTest12
{
	public static void main(String[ ] args) throws Exception 
	{
		int rno = 0, age = 0;
		String name = "", address = "";
		String qry = "";
		
		rno = Integer.parseInt(args[0]);
		
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		String url = "jdbc:odbc:OracleDSN";

		Connection cn = DriverManager.getConnection(url, "system", "tiger");
		
		qry = "SELECT * FROM studentstb where rno = ?";
		
		PreparedStatement pst = cn.prepareStatement(qry);
		pst.setInt(1, rno);
		
		pst.execute();
		
		ResultSet rs = pst.getResultSet();

		System.out.println("Rno\tName\tAge\tAddress");
		while (rs.next()) 
		{
			rno = rs.getInt(1);
			name = rs.getString(2);
			age = rs.getInt(3);
			address = rs.getString(4);
			System.out.println("" + rno + "\t" + name + "\t" + age + "\t" + address);
		}

		rs.close();
		pst.close();
		cn.close();
	}
}
