class  Test
{
	int i, j;

	Test( int a, int b )
	{
		i = a;
		j = b;
	}

	void meth( int i, int j )
	{
		i *= 2;
		j /= 2;
	}
}

class  CallByVal
{
	public static void main( String args[ ] )
	{
		Test ob = new Test( 10, 20 );
		
		System.out.println( " Values Before Call : " );
		System.out.println( " A = " + ob.i + ", B = " + ob.j );
	
		ob.meth( ob.i, ob.j );
		
		System.out.println( " Values After Call  : " );
		System.out.println( " A = " + ob.i + ", B = " + ob.j );
	}
}
