import java.sql.*;

public class  JdbcTest2
{
	public static void main(String[ ] args) throws Exception 
	{
		int rno = 0, age = 0;
		String name = "", address = "";
		String qry;
		
		Connection cn = getConnection();
		Statement st = cn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);

		qry = "SELECT * FROM studentstb";
		ResultSet rs = st.executeQuery(qry);

		System.out.printf("\n%5s %-10s %5s %-15s", "Rno","Name","Age","Address");
		while (rs.next()) 
		{
			rno = rs.getInt(1);
			name = rs.getString(2);
			age = rs.getInt(3);
			address = rs.getString(4);
			System.out.printf("\n%5d %-10s %5d %-15s", rno, name, age, address);
		}

		rs.close();
		st.close();
		cn.close();
	}

	private static Connection getConnection() throws Exception 
	{
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		String url = "jdbc:odbc:OracleDSN";

		return  DriverManager.getConnection(url, "system", "tiger");
	}
}
