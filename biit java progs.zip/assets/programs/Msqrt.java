class  Msqrt
{
	public static void main( String args[ ] )
	{
		double n = Math.sqrt( 625 );
		System.out.println("Square root of 625 : " + n );
	}
}
