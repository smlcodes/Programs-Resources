import java.awt.*;
import java.applet.*;

/*
<applet code="Applet06" width="300" height="50">
	<param name="message" value="Java makes the Web move!">
</applet>
*/

public class  Applet06 extends Applet implements 
Runnable 
{
	String msg;
	Thread t = null;
	boolean flag;

	public void init() 
	{
		setBackground(Color.yellow);
		setForeground(Color.red);
	}

	public void start() 
	{
		msg = getParameter("message");
		if(msg == null) msg = "Message not found.";
		msg = " " + msg;
		t = new Thread(this);
		flag = false;
		t.start();
	}

	public void run() 
	{
		char ch;
		for( ; ; ) 
		{
			try 
			{
				repaint();
				Thread.sleep(250);
				ch = msg.charAt(0);
				msg = msg.substring(1, msg.length());
				msg += ch;
				if( flag )
					break;
			} 
			catch(InterruptedException e) 
			{ }
		}
	}

	public void stop() 
	{
		flag = true;
		t = null;
	}

	public void paint(Graphics g) 
	{
		g.drawString(msg, 50, 30);
	}
}
