class  DeclareAtEnd
{
	public static void main( String args[ ] )
	{
		msg = "Let's learn JAVA !";
        System.out.println("Message : " + msg);
	}
	
	static String msg;
}
