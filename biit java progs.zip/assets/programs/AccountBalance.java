package MyPack;

class  Balance 
{
	String name;
	double bal;
	
	Balance(String n, double b) 
	{
		name = n;
		bal = b;
	}
	
	void show() 
	{
		if(bal<0)
			System.out.print("--> ");
		System.out.println(name + ": Rs. " + bal);
	}
}

class  AccountBalance 
{
	public static void main(String args[ ]) 
	{
		Balance current[ ] = new Balance[3];
		
		current[0] = new Balance("Khushal", 123.45);
		current[1] = new Balance("Sourabh", 345.12);
		current[2] = new Balance("Vivek", -12.34);
		
		for(int i=0; i<3; i++) 
		{
			current[ i ].show();
		}
	}
}
