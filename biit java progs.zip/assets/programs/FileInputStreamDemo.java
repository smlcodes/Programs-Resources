import java.io.*;

class  FileInputStreamDemo
{
	public static void main( String args[ ] ) throws IOException
	{
		// attach the file to FileInputStream
		FileInputStream fis = new FileInputStream("file1.txt");
		
		System.out.println(" File contents are : ");
		//Read character from fis and write them to monitor.
		int ch;
		while( (ch=fis.read()) != -1 )
		{
			System.out.print( (char)ch );
		}
		
		// close the file
		fis.close();
	}
}
