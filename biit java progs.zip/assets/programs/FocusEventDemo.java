import java.awt.*;
import java.awt.event.*;
import java.applet.*;

/*
<applet code="FocusEventDemo" width="200" height="100">
</applet>
*/

public class FocusEventDemo extends Applet implements FocusListener
{
	Button b1, b2, b3;
	Label l1, l2;
	
	public void init()
	{
		b1=new Button("First"); 
		b2=new Button("Second");
		b3=new Button("Third");
		l1=new Label("Focus Gained.");		
		l2=new Label("Focus Lost.");
		
		add(b1) ;	
		add(b2) ;	
		add(b3);	 
		add(l1) ;	
		add(l2);

		b1.addFocusListener(this);
		b2.addFocusListener(this);
		b3.addFocusListener(this);
	}

	public void focusGained(FocusEvent fe)
	{
		if(fe.getSource()==b1)
			l1.setText("Focus gained by : First");
		else if(fe.getSource()==b2)
			l1.setText("Focus gained by : Second" );
		else if(fe.getSource()==b3)
			l1.setText("Focus gained by : Third" );
	}

	public void focusLost(FocusEvent fe)
	{
		if(fe.getSource()==b1)
			l2.setText("Focus lost by : First");
		else if(fe.getSource()==b2)
			l2.setText("Focus lost by : Second" );
		else if(fe.getSource()==b3)
			l2.setText("Focus lost by : Third" );
	}
}
