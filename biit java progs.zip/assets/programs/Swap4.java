import javax.swing.JOptionPane;

class  Swap4
{
	public static void main( String args[ ] )
	{
		int  a=0, b=0, t;

		a = Integer.parseInt(JOptionPane.showInputDialog("Enter first Number : " ));
		b = Integer.parseInt(JOptionPane.showInputDialog("Enter second Number : " ));
	
		JOptionPane.showMessageDialog( null, " Before Swapping : " + a + "   " + b );
		
		a = a + b;
		b = a - b;
		a = a - b;
		
		JOptionPane.showMessageDialog( null, " After Swapping : " + a + "   " + b );
	}
}
