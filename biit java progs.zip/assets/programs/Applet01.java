import java.awt.*;
import java.applet.*;

/*
	<applet code="Applet01" width="300" height="200">
	</applet>
*/

public class  Applet01  extends  Applet 
{
	public void init() 
	{
		setBackground(Color.yellow);
		System.out.println("init() called.");
	}

	public void start() 
	{
		System.out.println("start() called.");
	}

	public void stop() 
	{
		System.out.println("stop() called.");
	}

	public void destroy() 
	{
		System.out.println("destroy() called.");
	}
	
	public void paint(Graphics g) 
	{
		System.out.println("paint() called.");
		g.drawString("BIIT Computer Education", 50, 100);
	}
}
