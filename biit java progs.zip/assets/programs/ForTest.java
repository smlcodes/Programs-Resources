class  ForTest
{
	public static void main( String args[ ] )
	{
		int i;

		for( i=1 ; i<=5 ; i++ )
		{
			System.out.print( "  " + i );
		}
	}
}
