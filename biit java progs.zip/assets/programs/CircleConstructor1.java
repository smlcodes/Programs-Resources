class  Circle
{
	private double radius;
	
	Circle()
	{
		radius = 10.0;
	}
	
	public double area()
	{
		return 3.14 * radius * radius;
	}
} 

public class  CircleConstructor1
{
	public static void main( String args[ ] )
	{ 
		Circle c1 = new Circle(); 
		
		System.out.println(" Area of Circle : " + c1.area()); 
	}
}
