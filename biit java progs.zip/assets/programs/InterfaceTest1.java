interface  A
{
	void showA();
}

class Test  implements  A
{
	public void showA()
	{
		System.out.println("showA() of A interface.");
	}
}

class  InterfaceTest1
{
	public static void main( String args[ ] )
	{
		Test  t1 = new Test();
		t1.showA();
		
		A  a1 = new Test();
		a1.showA();
		
		a1 = t1;
		a1.showA();
	}
}
