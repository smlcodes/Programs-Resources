class  MString11
{
	public static void main( String args[ ] )
	{
		String s1 = "BIIT : " + 5 + 5;	
		String s2 = "BIIT : " + (5 + 5);

		System.out.println( s1 );
		System.out.println( s2 );
	}
}
