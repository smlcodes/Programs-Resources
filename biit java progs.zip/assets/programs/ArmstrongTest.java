class  ArmstrongTest
{
	public static void main( String args[ ] )
	{
		int r, n, x, sum;
		
		n = Integer.parseInt( args[0] );
		x = n;
		
		sum = 0;
		while( n != 0 )
		{
			r = n % 10;
			sum = sum + ( r * r * r );
			n = n / 10;
		}
		
		if( sum == x )
			System.out.println( " Number " + x + " is a Amstrong Number." );
		else
			System.out.println( " Number " + x + " is NOT a Amstrong Number." );
	}
}
