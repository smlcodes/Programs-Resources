class Wrapper5
{
	public static void main(String args[ ]) 
	{
		Integer iOb = 100;
		Double dOb = 123.45;

		dOb = dOb + iOb;
		System.out.println("dOb after expression: " + dOb);
	}
}
