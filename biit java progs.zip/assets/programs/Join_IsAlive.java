class A implements Runnable
{
	String name;
	Thread t;

	A( String tname )
	{
		name = tname;
		t = new Thread( this, name );
		t.start();
	}

	public void run()
	{
		try
		{
			for( int i=1 ; i<=5 ; i++ )
			{
				System.out.println( name + " = " + i );
				Thread.sleep( 300 );
			}
			System.out.println( "END OF = " + name );
		}
		catch( Exception e )
		{ }
	}
} 

class Join_IsAlive
{
	public static void main( String args[ ] )
	{
		A nt1 = new A( "Thread1" );
		System.out.println( "Thread1 is alive :: " + nt1.t.isAlive() );

		A nt2 = new A( "Thread2" );
		System.out.println( "Thread2 is alive :: " + nt2.t.isAlive() );

		A nt3 = new A( "Thread3" );
		System.out.println( "Thread3 is alive :: " + nt3.t.isAlive() );
		
		try
		{
			nt1.t.join();
			nt2.t.join();
			nt3.t.join();
		}
		catch( Exception e )
		{  }
		
		System.out.println( "Thread1 is alive = " + nt1.t.isAlive() );
		System.out.println( "Thread2 is alive = " + nt2.t.isAlive() );
		System.out.println( "Thread3 is alive = " + nt3.t.isAlive() );
		
		System.out.println( "End of main." );
	}
}
