class  A
{
	public void display(int i)
	{
		System.out.println( "int : " + i );
	}
	
	public void  display(long l)
	{
		System.out.printf( "long : " + l );
	}
	
	public void display(float f)
	{
		System.out.printf( "float : " + f );
	}
	
	public void display(double d)
	{
		System.out.printf( "double : " + d );
	}
} 

public class  MethodOverloadingClass1
{
	public static void main( String args[ ] )
	{ 
		A  ob = new A(); 
		
		ob.display(10); 
		ob.display(20L); 
		ob.display(12.3f); 
		ob.display(23.4); 
		
		double d = 123.456;
		ob.display((int)d); 
		ob.display((long)d); 
		ob.display((float)d); 
		ob.display(d); 
	}
}
