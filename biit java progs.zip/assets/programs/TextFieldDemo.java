import java.awt.*;
import java.awt.event.*;
import java.applet.*;

/*
<applet code="TextFieldDemo" width=350 height=150>
</applet>
*/

public class TextFieldDemo extends Applet implements ActionListener 
{
	TextField tfname, tfpass;

	public void init() 
	{
		Label lblname = new Label("Name: ", Label.RIGHT);
		Label lblpass = new Label("Password: ", Label.RIGHT);
		tfname = new TextField(12);
		tfpass = new TextField(8);
		tfpass.setEchoChar('?');
		
		add(lblname);
		add(tfname);
		
		add(lblpass);
		add(tfpass);

		tfname.addActionListener(this);
		tfpass.addActionListener(this);
	}
	
	public void actionPerformed(ActionEvent ae) 
	{
		repaint();
	}

	public void paint(Graphics g) 
	{
		g.drawString("Name: " + tfname.getText(), 6, 60);
		g.drawString("Selected text in name: " + tfname.getSelectedText(), 6, 80);
		g.drawString("Password: " + tfpass.getText(), 6, 100);
	}
}
