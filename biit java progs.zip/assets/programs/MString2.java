class  MString2
{
	public static void main( String args[ ] )
	{
		char ch[ ] = { 'B', 'I', 'I', 'T' };
		String s = new String( ch, 2, 2 );	

		System.out.println( " String = " + s );

		// String s1 = 2013;			//  Error
		String s1 = "" + 2013;
		System.out.println( " String = " + s1 );
	}
}
