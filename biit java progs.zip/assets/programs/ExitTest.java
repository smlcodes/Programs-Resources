class ExitTest
{
	public static void main( String args[] )
	{
		int a = 10;
		System.out.println( "AAA" );
		if( a == 10 )
			System.exit(0);
		System.out.println( "BBB" );
	}
}
