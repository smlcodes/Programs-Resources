class  Wrapper4
{
	public static void main(String args[ ]) 
	{
		Boolean bOb = true;

		if (bOb)
		{
			System.out.println("bOb is true");
		}
		
		Character cOb = 'b'; 
		char ch = cOb; 

		System.out.println("ch is " + ch);
	}
}
