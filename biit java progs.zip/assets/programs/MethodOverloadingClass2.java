class  A
{
	public void display(int i, String s)
	{
		System.out.println( "int : " + i + ", String : " + s );
	}
	
	public void display(String s, int i)
	{
		System.out.println( "String : " + s + ", int : " + i );
	}
} 

public class  MethodOverloadingClass2
{
	public static void main( String args[ ] )
	{ 
		A ob = new A(); 
		
		ob.display(10, "BIIT"); 
		ob.display("JAVA", 20); 
				
		double d = 123.456;
		ob.display((int)d, "Bhilai"); 
		ob.display("Maitri Nagar", (int)d); 
	}
}
