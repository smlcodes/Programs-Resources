import java.awt.*;
import java.applet.*;

/*
<applet code="FillRectTest1a" width="200" height="100" >
</applet>
*/

public class FillRectTest1a  extends  Applet  
{
	public void paint(Graphics g) 
	{
		setBackground( Color.yellow );
		g.fillRect (20, 20, 160, 60);  
	}
}
