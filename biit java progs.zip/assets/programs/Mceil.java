class  Mceil
{
	public static void main( String args[ ] )
	{
		double n = Math.ceil( 4.0005d );
		System.out.println( " Value : " + n );
	}
}
