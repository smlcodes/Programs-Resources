interface  A
{
	void showA();
}

interface  B 
{
	void showB();
}

class  C  implements  A, B
{
	public void showA()
	{
		System.out.println("showA() of A interface.");
	}
	
	public void showB()
	{
		System.out.println("showB() of B interface.");
	}
}

class InterfaceTest8
{
	public static void main( String args[ ] )
	{
		C  t = new  C();
		t.showA();
		t.showB();
	}
}
