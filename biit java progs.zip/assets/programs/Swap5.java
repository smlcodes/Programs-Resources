import java.io.*;

class Swap5
{
	public static void main( String args[ ] ) throws IOException
	{
		int  a=0, b=0, t;
		Console cn = System.console();
		
		a = Integer.parseInt( cn.readLine( "Enter first Number : " ));
		b = Integer.parseInt( cn.readLine( "Enter second Number : " ));
	
		System.out.println( " Before Swapping : " + a + "   " + b );
		
		a = a + b;
		b = a - b;
		a = a - b;
		
		System.out.println( " After Swapping : " + a + "   " + b );
	}
}
