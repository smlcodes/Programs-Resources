class  StrArray
{
	public static void main( String args[ ] )
	{
		final int days = 7;

		String str[ ] = { "Sunday", �Monday", �Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"   };
  	
		for( int  j=0 ; j<days ; j++ )
		{
  			System.out.print("    " + str[ j ]);
		}
  	}
}
