class  PerfectTest
{
	public static void main( String args[ ] )
	{
		int  i, t, n, sum;

		n = Integer.parseInt( args[0] );

		sum = 0;
		for( i=1 ; i<=n/2 ; i++ )
		{
			if( n % i == 0 )
			{
				sum = sum + i;
			}
		}
	
		if( n == sum )
			System.out.println( "\n The Number " + n + " is a PERFECT Number." );
		else
			System.out.println( "\n The Number " + n + " is NOT a PERFECT Number." );
	}
}
