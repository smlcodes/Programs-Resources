import java.applet.*;
import java.awt.event.*;

/*
<applet  code="MouseAdapterAnonymousInnerTest" width="300"  height="100">
</applet>
*/

public class MouseAdapterAnonymousInnerTest extends Applet 
{
	public void init() 
	{
		addMouseListener(new MouseAdapter() 
		{
			public void mouseClicked(MouseEvent me) 
			{
				showStatus("Mouse Clicked.");
			}
		} );
	}
}
