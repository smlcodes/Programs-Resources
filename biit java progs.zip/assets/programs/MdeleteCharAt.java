class  MdeleteCharAt
{
	public static void main( String args[ ] )
	{
		StringBuffer sb = new StringBuffer( "BIIT CComputer Education." );

		System.out.println( " String = " + sb );
		
		sb = sb.deleteCharAt( 5 );

		System.out.println( " String = " + sb );
	}
}
