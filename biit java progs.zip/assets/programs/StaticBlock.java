class  StaticBlock 
{
	static int a;
   
	static 
	{
		System.out.println("Static block initialized.");
		a = 10;
	}
	
   	static void show() 
	{
		System.out.println("a = " + a);
	}
	
	public static void main(String args[ ]) 
	{
		show();
	}
}
