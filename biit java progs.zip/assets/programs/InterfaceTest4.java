interface A
{
	void showA();
}

interface B extends A 
{
	void showB();
}

class Test  implements B
{
	public void showA()
	{
		System.out.println("showA() of A interface.");
	}
	
	public void showB()
	{
		System.out.println("showB() of B interface.");
	}
}

class InterfaceTest4
{
	public static void main( String args[ ] )
	{
		A  a1 = new Test();
		a1.showA();
		
		B b1 = new Test();
		b1.showA();
		b1.showB();
	}
}
