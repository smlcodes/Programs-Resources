/*  Defining Remote Interface( addRmi.java ) */
import java.rmi.*;

interface  addRmi  extends  Remote
{
	public int addNum( int x, int y ) 
throws RemoteException;
}

// [ ServerRmi.java ] : 
/* Defining Server Application( ServerRmi.java ) */
import java.rmi.*;
import java.rmi.server.*;

public class  ServerRmi  extends  UnicastRemoteObject implements addRmi
{
	public ServerRmi() throws RemoteException
	{  }

	public static void main( String args[ ] ) throws Exception
	{
		System.out.println( "Server Starts..." );
		ServerRmi s = new ServerRmi();
		Naming.rebind( "ServerRMI", s );
	}

	public int addNum( int a1, int a2 )
	{
		return ( a1 + a2 );
	}
}

// [ ClientRmi.java ] : 
/* Defining Remote Interface( ClientRmi.java ) */
import java.io.*;
import java.rmi.*;
import java.net.*;

public class  ClientRmi
{
	public static void main( String args[ ] ) throws Exception
	{	
		InputStreamReader isr = new InputStreamReader( System.in );
		BufferedReader br = new BufferedReader( isr );
		InetAddress ia = InetAddress.getLocalHost();

		String ip = ia.toString().substring( ia.toString().indexOf( '/' )+1);
		String url = "rmi://" + ip + "/ServerRMI";
		
		System.out.println( "Remote Method Invocation ::: " );
		addRmi m = (addRmi) Naming.lookup( url );
		
		System.out.print( " Enter first number : " );
		int a = Integer.parseInt( br.readLine() );
		System.out.print( " Enter second number : " );
		int b = Integer.parseInt( br.readLine() );

		System.out.println( " Sum : " + m.addNum( a, b ));
	}
}
