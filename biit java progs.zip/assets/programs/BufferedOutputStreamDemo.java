import java.io.*;

class  BufferedOutputStreamDemo
{
	public static void main( String args[ ] ) throws IOException
	{
		// attach keyboard to DataInputStream
		DataInputStream dis = new DataInputStream( System.in );
		
		// attach file to FileOutputStream
		FileOutputStream fos = new FileOutputStream( "file1.txt" );
		BufferedOutputStream bos = new BufferedOutputStream( fos, 1024 );
		
		System.out.println("Enter string ( $ to end ) : ");
		char ch;
		
		// read character from dis into ch and write them into bos.
		while( (ch=(char)dis.read()) != '$' )
		{
			bos.write(ch);
		}
		
		// close the file.
		bos.close();
	}
}
