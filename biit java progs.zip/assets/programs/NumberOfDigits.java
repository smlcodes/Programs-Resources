class  NumberOfDigits
{
	public static void main( String args[ ] )
	{
		int n, c;
		
		n = Integer.parseInt( args[0] );

		c = 0;
		while( n != 0 )
		{
			n = n / 10;
			c++;
		}
		System.out.println( " Number of Digits : " + c );
	}
}
