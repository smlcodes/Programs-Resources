// File-1 : ChatServer.java ( SERVER  SIDE ) 

import java.io.*;
import java.net.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class ChatServer
{
 	public static void main( String args[ ] ) throws Exception
  	{
       	MyFrame F1=new MyFrame("SERVER");
    }
}

class MyFrame extends JFrame
{
 	JTextArea A1,A2;
    JButton B1,B2;
    String s1="";
    JScrollPane P1,P2;
    JLabel L1,L2;
            
    public static int buffer_size=1024;
    public static ServerSocket ss;
    public static Socket cs;
    public static byte buffer[ ]=new byte[buffer_size];
    ObjectOutputStream OS;
    ObjectInputStream IS;

    MyFrame( String s ) throws Exception
    {
       	super(s);
        ss = new ServerSocket( 2000, 20 );
                    
        setLayout( new FlowLayout() );
        add( L1 = new JLabel( "Typed Message : " ) );

        A1 = new JTextArea( 8, 36 );
        P1 = new JScrollPane( A1 );
        getContentPane().add( P1 );
        add( L2 = new JLabel( "Received:" ) );

        A2 = new JTextArea( 8, 36 );
		P2 = new JScrollPane( A2 );
        getContentPane().add( P2 );

        add( B1 = new JButton( "Send" ) );
        B1.addActionListener( new ActionListener()
        {
          	public void actionPerformed(ActionEvent ae) 
            {
               	try   
				{
                   	OS = new ObjectOutputStream( cs.getOutputStream() );
                    s1 = �Server : � + A1.getText();
                                         
                    OS.writeObject( s1 );     
                    OS.flush();                                      
                    A2.append( "\n" + s1 );
                    A1.setText( " " );
                }
                catch( Exception e )
                {  }
            }
       	} );
        add( B2 = new JButton( "Cancel" ) );
        setSize( 450, 400 );
        setVisible( true ); 
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
             
		cs = ss.accept(); 
   
        while( true ) 
        { 
          	IS = new ObjectInputStream ( cs.getInputStream() );                      
            s1 = (String)( IS.readObject() );
            A2.append( "\n" + s1 );
        }
   	}
}

// File-2 : ChatClient.java ( CLIENT   SIDE )

import java.io.*;
import java.net.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class ChatClient
{
	public static void main( String args[ ] ) throws Exception
	{
   		MyFrame2   F1 = new MyFrame2( "CLIENT" );   	
	}
}

class MyFrame2 extends JFrame
{
 	JTextArea A1, A2;
    JButton B1, B2;
    String s1 = "";
    JScrollPane P1, P2;
    JLabel L1, L2;
           
    public static int buffer_size = 1024;
    public static ServerSocket  ss;
    public static Socket cs;
    public static byte buffer[ ] = new byte[buffer_size];
    ObjectOutputStream OS;
    ObjectInputStream IS;

    MyFrame2( String s ) throws Exception
    {
		super( s );
        InetAddress A = InetAddress.getLocalHost();
        cs = new Socket( A, 2000 );

		//	PC1 is Server Name.
		//  cs = new Socket( �PC1�, 2000 );

        setLayout( new FlowLayout() );
        add( L1 = new JLabel( "Typed Message : " ) );
                
        A1 = new JTextArea( 8, 36 );
        P1 = new JScrollPane( A1 );
        getContentPane().add( P1 );

		add( L2 = new JLabel( "Received : " ) );
        A2 = new JTextArea( 8, 36 ) ;
        P2 = new JScrollPane( A2 );
        getContentPane().add( P2 );

        add( B1 = new JButton( "Send" ) );
                 
  		//  sending the message
        B1.addActionListener( new ActionListener()
        {
        	public void actionPerformed(ActionEvent ae ) 
            {
                try   
				{
					OS = new ObjectOutputStream( cs.getOutputStream() );
                    s1 = �Client : � + A1.getText();
                    OS.writeObject( s1 );   
                    OS.flush();                                        
                    A2.append( "\n" + s1 );
                    A1.setText( " " );
                }
                catch( Exception e )
                {    }
      		}
        } );
        add( B2 = new JButton( "Cancel" ) );

        setSize( 450, 400 );
        setVisible( true ); 
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // receiving the message
        while( true ) 
        {
           	IS = new ObjectInputStream ( cs.getInputStream() );                      
            s1 = (String)( IS.readObject() );
            A2.append( "\n" + s1 );
        }
    }
}
