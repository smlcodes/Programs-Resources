class  DoWhileTest
{
	public static void main( String args[ ] )
	{
		int   i = 1;			// 1.  Initialization

		do
		{
			System.out.print( "  " + i );
			i++;				// 3.  Increment.
		}while ( i <= 5 );		// 2.  Test / Condition
	}
}
